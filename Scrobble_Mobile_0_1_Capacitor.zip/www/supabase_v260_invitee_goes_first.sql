-- Scrobble 2.6
-- Invited opponent goes first.
-- Run once in the Supabase SQL Editor before deploying/testing 2.6.

create or replace function public.join_scrobble_game(p_invite_code text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  g public.games%rowtype;
  existing smallint;
  cnt int;
begin
  if uid is null then raise exception 'Not signed in'; end if;

  select *
  into g
  from public.games
  where invite_code = upper(p_invite_code)
    and status = 'active'
  for update;

  if g.id is null then raise exception 'Game not found'; end if;

  select player_number
  into existing
  from public.game_players
  where game_id = g.id
    and player_id = uid;

  if existing is not null then
    return jsonb_build_object('id', g.id, 'player_number', existing);
  end if;

  select count(*)
  into cnt
  from public.game_players
  where game_id = g.id;

  if cnt >= 2 then raise exception 'This game already has two players'; end if;

  insert into public.game_players(game_id, player_id, player_number, rack)
  values(g.id, uid, 2, coalesce(g.pending_rack, '[]'::jsonb));

  -- Player 2 is the invited opponent, so Player 2 owns the opening turn.
  update public.games
  set pending_rack = null,
      current_player_id = uid,
      updated_at = now()
  where id = g.id;

  return jsonb_build_object('id', g.id, 'player_number', 2);
end;
$$;

grant execute on function public.join_scrobble_game(text) to authenticated;
