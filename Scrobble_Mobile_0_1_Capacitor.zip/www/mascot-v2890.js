/* Scrobble 2.89 — lower-right supplied mascot pose, static arms, frequent blinking. */
(()=>{'use strict';try{
const rigs=[],reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function im(c,s){const e=document.createElement('img');e.className=c;e.src=s;e.alt='';e.draggable=false;return e}
function build(h,k){if(!h)return null;h.textContent='';h.classList.add('mascotRigHost',`mascotRigHost--${k}`);h.setAttribute('role','img');h.setAttribute('aria-label','Yay Everybody mascot');const r=document.createElement('div');r.className='mascotRig mascotRig289';r.append(im('mascotReference289','icons/yay-puppet-static-v289.png'),im('mascotBlink289','icons/yay-puppet-eyes-closed-v289.png'));h.appendChild(r);rigs.push(r);return r}
function blink(r,d=false){if(!r||reduced||document.hidden)return;const c=()=>{r.classList.add('isBlinking');setTimeout(()=>r.classList.remove('isBlinking'),145)};c();if(d)setTimeout(c,255)}
function schedule(r){setTimeout(()=>{blink(r,Math.random()<.2);schedule(r)},2600+Math.random()*2200)}
const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');build(document.querySelector('#scrobble-v4 .yayButton'),'game');rigs.forEach(schedule);if(splash)setTimeout(()=>blink(splash,true),700);window.ScrobbleMascot={blink:()=>rigs.forEach(r=>blink(r,true)),wave:()=>{},celebrate:()=>{}};
}catch(_){}})();