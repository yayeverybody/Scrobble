/* Scrobble 2.93 — fixed mascot, original aligned blink, one arm wave only. */
(()=>{'use strict';try{
const rigs=[],reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function image(c,s){const e=document.createElement('img');e.className=c;e.src=s;e.alt='';e.draggable=false;return e}
function build(host,kind){
 if(!host)return null;
 host.replaceChildren();host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
 const r=document.createElement('div');r.className='mascotRig293';
 r.append(
  image('mascotPose293 mascotOpen293','icons/yay-puppet-open-v293.png?v=293'),
  image('mascotPose293 mascotBlink293','icons/yay-puppet-blink-v293.png?v=293'),
  image('mascotWaveArm293','icons/yay-puppet-wave-arm-v293.png?v=293')
 );
 host.append(r);rigs.push(r);return r;
}
function blink(r,doubleBlink=false){
 if(!r||reduced||document.hidden)return;
 const c=()=>{r.classList.add('isBlinking');setTimeout(()=>r.classList.remove('isBlinking'),155)};
 c(); if(doubleBlink)setTimeout(c,270);
}
function schedule(r){setTimeout(()=>{blink(r,Math.random()<.18);schedule(r)},2600+Math.random()*2200)}
const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
build(document.querySelector('#scrobble-v4 .yayButton'),'game');
rigs.forEach(schedule);
if(splash){
 setTimeout(()=>blink(splash,true),900);
 if(!reduced)setTimeout(()=>{
   splash.classList.add('doArmWave293');
   setTimeout(()=>splash.classList.remove('doArmWave293'),1000);
 },1450);
}
window.ScrobbleMascot={blink:()=>rigs.forEach(r=>blink(r,true)),wave:()=>{if(splash){splash.classList.remove('doArmWave293');void splash.offsetWidth;splash.classList.add('doArmWave293')}},celebrate:()=>{}};
}catch(e){console.warn('mascot 2.93',e)}})();