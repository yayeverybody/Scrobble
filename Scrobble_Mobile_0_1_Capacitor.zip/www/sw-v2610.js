const CACHE_VERSION='scrobble-v2610';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>{
  let data={};try{data=event.data?event.data.json():{}}catch(e){data={body:event.data?.text()||''}}
  const n=data.notification||data;
  const title=n.title||'Your turn in Scrobble!';
  const options={body:n.body||'Your opponent played. It’s your move.',icon:n.icon||'icons/scrobble-mascot-v265-192.png',badge:n.badge||'icons/scrobble-mascot-v265-192.png',tag:n.tag||'scrobble-turn',renotify:true,data:{url:n.navigate||n.url||'./'}};
  event.waitUntil(self.registration.showNotification(title,options));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();const target=new URL(event.notification.data?.url||'./',self.location.origin).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    for(const client of list){if('navigate' in client){client.navigate(target);return client.focus()}}
    return self.clients.openWindow?self.clients.openWindow(target):undefined
  }))
});
