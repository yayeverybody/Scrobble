SCROBBLE 2.0 CLEAN REBUILD

Architecture
------------
index.html           DOM only. No inline application CSS or JavaScript.
styles-v200.css      Visual styling + one app-shell layout layer.
game-engine-v200.js  Board/game engine, scoring, drag/drop, zoom/pan, CPU.
app-v200.js          Supabase, auth, Games dashboard, invites, navigation.
_headers             Netlify cache policy.

Important
---------
- The game engine was transplanted from the approved V13.3 baseline.
- Old viewport/background/board-height patch layers were removed.
- Splash is the only fixed screen and is the only visible app layer during boot.
- Games and Board use normal document flow; no nested viewport scrollers.
- Only one simple top reset is used during explicit screen navigation/pageshow.
- HTML is no-cache. Versioned CSS/JS files are immutable to prevent stale mixed builds.
- Future releases should bump asset filenames (v201, v202, etc.) whenever CSS/JS changes.

Scrobble 2.1
------------
Center 7,7 retains triple-word scoring but is rendered Scrobble blue with a yellow Boognish mark.

Scrobble 2.6
------------
New multiplayer rule: the invited opponent (Player 2) takes the first turn.

IMPORTANT:
Run supabase_v260_invitee_goes_first.sql once in the Supabase SQL Editor.
The browser code already honors current_player_id/current_slot, so no game-engine
turn hack is needed. The database remains the authoritative turn owner.

Scrobble 2.8
------------
Deterministic startup/data-flow release:
- Initial auth session has one bootstrap owner.
- Auth callbacks cannot race the initial boot.
- Games reads/renders are single-flight.
- Quiet refresh cannot race a foreground render.
- Pending friend-game creation is consumed before its network call.
- supabase_v280_duplicate_guard.sql adds DB-level invite-code uniqueness.

Run supabase_v280_duplicate_guard.sql once in Supabase SQL Editor.
If it reports existing duplicate invite codes, end/delete those duplicate waiting
games, then run it again.

Scrobble 2.10
-------------
Multiplayer board continuity:
- After submitting a turn, the player stays on the board.
- The board reloads authoritative cloud state after the save.
- While waiting for the opponent, the open board checks for updates every 5 seconds.
- When the opponent plays, the board, scores, rack/turn state, and last-move notice refresh in place.
- Challenge submit/resolve also stays on the board.

Scrobble 2.11
-------------
- Tile point-value numerals increased 50% (24 -> 36 in the tile SVG).
- Pending legal placements are automatically checked against the same Scrobble
  dictionary validation used by PLAY.
- When every word formed by the placement is valid, a green check and the
  actual move score appear beside the newly laid word.
- Preview recalculates whenever pending tiles are added, moved, or recalled.
- PLAY remains the action that commits the turn.

Scrobble 2.12
-------------
- Kept tile point-value numerals 50% larger and moved them inward/down for proper spacing.
- Moved the live green validation check + move score to the beginning of the word.
- Removed the white border from both the green check and the point-total badge.

Scrobble 2.13
-------------
- Rebalanced tile typography so enlarged point values no longer touch letters.
- Green valid-word check stays at the beginning of the word and is 40% smaller.
- Live move point total now appears at the end of the word.
- Check and score remain borderless.

Scrobble 2.14
-------------
- Fixed games sometimes opening with the board already zoomed/panned upward.
- Saved Computer games now always open at the normal 1x board view.
- Cloud games also reset stale zoom/pan state when loaded.
- Existing pinch zoom and one-finger pan still work after the game opens.

Scrobble 2.15
-------------
- Added a one-time SCROBBLE title wave on the splash screen.
- Each yellow title tile rises and enlarges in sequence, then settles about 10% larger.
- Animation starts shortly after the splash appears and completes before the existing splash exit.
- Reduced-motion users get a static slightly enlarged title.

Scrobble 2.16
-------------
- After the SCROBBLE splash-title wave finishes, YAY EVERYBODY GAMES briefly
  becomes bolder and about 12% larger for half a second, then returns to normal.

Scrobble 2.17
-------------
- Splash SCROBBLE wave runs 25% faster, with the YAY EVERYBODY GAMES pop retimed
  to begin immediately after the faster wave.
- Board loading guard: the approved black SCROBBLE game header is now sticky at
  the top of the game page. This avoids another layer of timed scroll resets and
  protects against mobile Chrome restoring the document partway down the page.

Scrobble 2.18
-------------
- Board PLAY button now uses the same yellow gradient as the Scrobble letter tiles, with black PLAY text.

Scrobble 2.19
-------------
- Swap mode no longer inserts a tray between the board and rack/footer.
- The existing swap tray now appears as an overlay across the lower portion of
  the board, so the rack and footer remain fixed in their normal positions.
- Existing tap/drag tile selection and SWAP confirmation behavior is unchanged.

Scrobble 2.20
-------------
- Games page timestamps are easier to scan.
- Games updated within the past 7 days show the weekday instead of the date
  (for example: Sunday, 11:24 AM).
- Older games show the numeric date plus time.
- Seconds are removed from all Games page timestamps.
- Applies to active/completed multiplayer and computer games.

Scrobble 2.21
-------------
- Reduced point-value numbers on rack/tile-row tiles by 30%.
- Board-tile point values remain unchanged.

Scrobble 2.22
-------------
- Reduced rack/tile-row point-value numbers another 30% (25.2px to 17.64px).

Scrobble 2.23
-------------
- After dismissing an opponent's Last Move notice, the played word tiles wave on the board so the move is easy to locate.
- The board automatically focuses toward the animated word before the wave.
- Added LEADERBOARDS to the Games page.
- Added All-Time Wins and All-Time Points platform leaderboards for completed multiplayer games.
- Run supabase_v2230_leaderboards.sql once in Supabase SQL Editor to enable platform leaderboard data.

Scrobble 2.24
-------------
- Leaderboard typography now matches the rest of Scrobble.
- SCROBBLE at the top of the leaderboard is rendered as black letters on yellow tiles.
- ALL-TIME WINS and ALL-TIME POINTS headings are larger and bolder.
- Leaderboard names now resolve to actual usernames; SQL also falls back to auth username metadata.
- Run supabase_v2240_leaderboards.sql once in Supabase SQL Editor.

Scrobble 2.25
-------------
- Leaderboards now use the same blue/gradient visual language as the Games page.
- After the opponent-word wave finishes, the board automatically returns to the full-board 1x view.

Scrobble 2.26
-------------
- Fixed the recurring mobile board-load position shown in the 2.25 screenshot.
- The screenshot showed a normal 1x board but the entire game document restored too high,
  clipping the game header/player bar. Board entry now anchors the game shell to the top.
- No additional delayed scroll-reset timers were added.
- All 2.25 leaderboard styling and opponent-word wave/zoom-out behavior retained.

Scrobble 2.27
-------------
- Leaderboards now explicitly inherit the exact Games-page font stack:
  Arial,Helvetica,sans-serif
- No other visual or gameplay changes.

Scrobble 2.28
-------------
- Score totals now roll through the added points with a gas-pump/odometer-style flip.
- Existing score font, size, color, and positioning are unchanged.
- Opening or reloading a game shows the current score immediately instead of animating from zero.

Scrobble 2.29
-------------
- Slowed and smoothed the zoom-back to the full board after the opponent-word wave.
- Score totals now take a full 3 seconds to roll from the old total to the new total.
- Score typography and layout remain unchanged.

Scrobble 2.30
-------------
- Fixed dictionary false positives: Datamuse spelling matches without real
  definitions no longer count as valid words.
- Human moves now only auto-approve when the word is positively verified.
- Computer-generated moves are now checked by the same real dictionary before
  they can be committed. If a candidate is invalid, the computer tries another
  move and otherwise swaps/passes.
- Existing board, animations, score pump, leaderboard, and mobile behavior retained.

Scrobble 2.31
-------------
- Restored reliable real-time green-check + point-total word preview.
- Added the dictionary.txt file the game was already coded to load (61,313 US English words),
  so common word validation no longer depends entirely on remote APIs.
- Live preview retries automatically if the dictionary is still loading.
- Computer moves now pass the same board-geometry validation as human moves.
- Every word formed by the computer is dictionary-verified before the move commits.
- Added a guard requiring all newly placed computer tiles to belong to one formed word,
  preventing unrelated-space placements.
- All 2.30 visuals, animations, score pump, leaderboard styling, and board behavior retained.

Scrobble 2.32
-------------
- Rack/tile-row tiles can now be manually dragged and reordered.
- Drag any tile left or right within the rack and drop it where you want it.
- Works through the existing desktop and mobile touch drag system.
- Rack-to-board dragging, swap mode, live dictionary preview, computer safeguards,
  score animation, and opponent-word animation are unchanged.

Scrobble 2.33
-------------
- Rack drag/drop now uses true insertion: dropping between tiles slides the neighboring
  tile(s) over to make room.
- The rack rearrangement movement is 40% slower and eased for smoother motion.
- Removed the intermittent iOS white focus/drop frame around the rack.
- All 2.32 dictionary, computer, live preview, score, board, and animation behavior retained.

Scrobble 2.34
-------------
- Rack/tile-row point values are 25% smaller.
- When it is the opponent's turn and the rack is disabled/gray, the PLAY button
  is now gray as well.
- All 2.33 rack reordering, dictionary, live preview, computer, score, and board
  animation behavior retained.

Scrobble 2.35
-------------
- Added restrained in-browser sound feedback: tile clack, valid-word ding,
  gas-pump score ticks/final ding, and sequential opponent-word wave taps.
- Added light vibration calls where supported. iPhone web browsers may ignore vibration.
- No external sound files and no visual/gameplay redesign.

Scrobble 2.36
-------------
- Removed the experimental Web Audio/haptic code after it caused a board-page regression.
- Games page: NEW GAME is dark blue; LEADERBOARDS is light blue.
- All approved gameplay and animation behavior retained.

Scrobble 2.37
-------------
- Games page NEW GAME button now uses the exact yellow gradient used by the game tiles,
  with black text.
- Leaderboards button and all gameplay behavior retained unchanged.

Scrobble 2.38
-------------
- Added HIGHEST POINT WORDS as the first leaderboard section.
- Shows the top four recorded multiplayer single-word plays: player, word, points.
- Requires supabase_v2380_highest_words.sql.
- Recording begins after the migration is installed; old games cannot be reconstructed
  reliably because historical per-word scores were not previously stored.

Scrobble 2.39
-------------
- Signed-in players can upload, replace, or remove an optional profile photo in Account.
- JPG/PNG/WebP, 2 MB maximum.
- Photos display as circular avatars on Games cards and on the game board.
- Existing username initial remains the fallback.
- Requires supabase_v2390_avatars.sql.

Scrobble 2.40
-------------
- Profile-photo upload now accepts normal phone photos without a 2 MB source-file limit.
- Photos are center-cropped and resized on the device to 512 x 512 before upload.
- Final uploads are compressed JPEGs, keeping Supabase storage/bandwidth small.
- Existing avatar storage migration remains valid; no new SQL is required.

Scrobble 2.41
-------------
- Rebuilt the Games page styling around the approved blue-gradient mockup.
- Medium-to-dark blue gradient replaces the dark/black lobby background.
- Leaderboards is now the left primary action; New Game is the right yellow action.
- Game cards use dark-blue gradients, white text, larger avatars, clearer turn states,
  stronger score hierarchy, and more breathing room.
- Active and completed games remain functionally unchanged; gameplay was not modified.

Scrobble 2.42
-------------
- Corrected 2.41: rebuilt the actual game-card markup, not just the surrounding dashboard.
- Larger circular opponent avatars, opponent-first naming, colored turn dot/status,
  timestamp beneath, separated score columns, chevrons for active games and green
  completion checks for completed games.
- Retains approved medium-to-dark blue Games-page gradient and swapped top buttons.

Scrobble 2.43
-------------
- Multiplayer opponent moves now have the same played-word notice/wave animation path as computer moves.
- Requires supabase_v2430_multiplayer_last_move.sql so get_scrobble_game returns the latest saved move.
- Added a one-time, per-account first-login rules overlay on the Games page.
- Rules explain valid-move green check/points, opponent review for unverified words, and loss of turn when a word is denied.

Scrobble 2.44
-------------
- Fixed multiplayer background refresh scrolling the live game underneath mobile browser chrome.
- Fixed multiplayer opponent-move animation turn detection (current_slot, not nonexistent current).
- Prevents the same opponent move notice from replaying on repeated polling.

Scrobble 2.45
-------------
- Fixed the signed-in player's own profile photo on multiplayer game boards.
- The board had been deliberately overwriting the current player's avatar_url with null;
  that override is removed, so both players now use their saved profile photos.

Scrobble 2.46
-------------
- Adds visible spacing between splash-screen SCROBBLE tiles while preserving the approved wave animation.
- Makes the sticky Games-page brand header carry its blue background while scrolling.

Scrobble 2.47
-------------
- Splash YAY EVERYBODY GAMES text now uses the same #a9ddff light blue as the Games page.

Scrobble 2.48
-------------
- Made the splash supporting copy (ALWAYS FREE / INVITE YOUR FRIENDS) larger and bolder.

Scrobble 2.49
-------------
- Added confirmation before submitting a word that Scrobble cannot verify.
- Uses the same in-game word-review popup as the opponent review flow.
- Explains that the word is not in the dictionary, that the opponent must approve it,
  and that a denial costs the player their turn.
- CANCEL keeps the unsubmitted tiles available to adjust; SUBMIT sends the review request.

Scrobble 2.50
-------------
- Added MAKE IT WEIRD to New Game with five stackable checkbox variations:
  Too Many T's, Vowel Movement, High Roller, Seven Heaven, and Oops! All Y's.
- Variations affect the actual bag, rack size, and scoring.
- Friend-game weird rules are stored with the cloud game.
- Invitees are shown exactly how the creator is making the game weird before joining.

Scrobble 2.51
-------------
- Fixed Make It Weird game creation crash caused by recursive High Roller tile-value lookup.
- Restyled the New Game modal to match the dark-blue/yellow Scrobble Games-page design.

Scrobble 2.52
-------------
- Games page red end-game X is 50% larger and inset farther from the card edges.
- COMPLETED GAMES now matches the size/weight of YOUR GAMES.
- Make It Weird no longer increases the standard 102-tile bag.
- Too Many T's, Vowel Movement, and Oops! All Y's now replace a proportional
  mix of other standard letters with the weird-rule tiles.

Scrobble 2.53
-------------
- Make It Weird now allows at most one optional variation at a time.
- Too Many T's is now All or None: the full 102-tile bag contains only A/L/O/R/N/E.
- Seven Heaven is now Too Many Tiles: 9-tile racks, kept on a single row.
- High Roller now makes J/Q/X/Z worth triple points.

Scrobble 2.54
-------------
- Removed the redundant Games page title.
- Pulled the Account and primary action area upward to use the freed space.

Scrobble 2.55
-------------
- Added installable web-app manifest and service worker.
- Added opt-in turn notification prompt styled to Scrobble.
- iPhone users are guided to Add to Home Screen before enabling Web Push.
- Added per-user push subscription storage and turn-change notification trigger SQL.
- Added Supabase Edge Function source for standards-based Web Push.
- Notification taps deep-link directly to the relevant game.
Scrobble 2.57
-------------
- Auth sessions now use explicit persistent browser storage and a stable storage key.
- A transient SIGNED_OUT event is rechecked before the sign-in gate is shown.
- Auth auto-refresh resumes whenever the app returns to the foreground.
- Tile drops use nearest-square board coordinates instead of exact DOM hit testing.
- Grid gaps and releases slightly outside an edge row now snap to a valid square.
Scrobble 2.58
-------------
- New accounts now receive browser-specific notification setup instructions.
- iPhone instructions identify Chrome, Safari, Edge, or Firefox and explain the
  required Add to Home Screen step.
- Android and desktop players receive the appropriate notification guidance.
- Signed-in players can reopen Notification Setup from the Account screen.
Scrobble 2.59
-------------
- Password-reset links now open the missing choose-a-new-password step.
- Signed-in players can set or change their password from Account at any time.
- The password setup explains that the installed Home Screen app has its own
  browser session and can use the new password for its first sign-in.
- Notification setup now explicitly uses the same Arial/Helvetica font stack
  as the Games page and game board.
Scrobble 2.60
-------------
- Fixed the tall-screen layout in Chrome's installed Home Screen mode.
- The rack remains directly beneath the board while the action controls are
  anchored at the bottom, eliminating the unexplained blue area below them.
Scrobble 2.61
-------------
- Replaced the Home Screen icon with the existing Yay Everybody mascot on a
  dark-blue background; the installed app label remains Scrobble.
- The player who starts uses the standard yellow tiles. The other player uses
  a more orange-yellow tile, with ownership saved on every new board tile.
- Existing legacy board tiles remain standard yellow because older saved games
  did not record which player placed each individual tile.
Scrobble 2.62
-------------
- Increased player-tile contrast: the game creator keeps the original yellow
  tiles and the invited opponent now uses dark-blue tiles.
- Dark-blue tiles use yellow letters and point values to match the game's
  established blue-and-yellow visual language.
Scrobble 2.64
-------------
- Restored the classic gold tiles for the game creator.
- The invited opponent now uses the same gold palette lightened by approximately
  50%, preserving the original look while making each player's words distinct.
- Both tile colors use the original dark lettering for easy readability.
Scrobble 2.65
-------------
- Removed the yellow circular border from the Home Screen and notification icon.
- Preserved the existing dark-blue background and Yay Everybody mascot artwork.
Scrobble 2.66
-------------
- Fixed the large blue gap that could appear between the letter rack and action
  buttons in Chrome's installed Home Screen mode on tall phones.
- The rack and its controls now remain one continuous group directly beneath
  the board, while any unavoidable surplus height stays below the controls.
Scrobble 2.67
-------------
- Replaced the tall-screen spacing overrides with adaptive viewport fitting.
- On taller phones, spare height is distributed across the header, player bar,
  board frame, rack area, and controls instead of collecting in one blue gap.
- On shorter phones, the complete game surface scales down proportionally so
  the board, rack, and controls remain visible together.
Scrobble 2.68
-------------
- Restored the PLAY button and footer icons to their normal heights.
- Adaptive surplus height now becomes breathing room between the tile rack and
  the footer controls instead of stretching the buttons vertically.
Scrobble 2.69
-------------
- Added a SHOW/HIDE control inside every password field, including sign-in,
  account creation, and password setup/change fields.
- Each control is keyboard accessible and identifies the password field it
  reveals for screen readers.
Scrobble 2.70
-------------
- Double-tap anywhere on the board to zoom to 2× around that spot.
- Double-tap again while zoomed to return to the complete board.
- Double-tap detection stays separate from tile dragging, pinch zoom, and
  one-finger panning; it is disabled while a rack tile is selected.
- Corrected touch-coordinate mapping when adaptive whole-screen scaling is active.
Scrobble 2.71
-------------
- Replaced the general-English validator with Scrobble Classic, a fixed offline
  word-game lexicon based on the public-domain ENABLE 2K list.
- Removed DictionaryAPI and Datamuse validation. A general dictionary definition
  can no longer make a non-playable name, trademark, abbreviation, or casual
  spelling pass automatically.
- Computer moves must now pass the same fixed lexicon as human moves; the broad
  computer vocabulary is used only to propose candidates.
- Words outside the lexicon still use Scrobble's opponent-review house rule.
Scrobble 2.72
-------------
- Restored sound as an isolated, failure-safe feedback module that cannot block
  the board or game engine if a browser refuses audio playback.
- Added an original puppet-chaos sound palette: varied wooden tile clacks,
  rubbery tile-return boops, kazoo-like valid-word flourishes, score ticks,
  a descending invalid-word whistle, bucket-of-blocks swapping, a sad pass,
  opponent-word wave taps, soft interface pops, and a puppet-band game finale.
- Audio unlocks only after a player interaction, as required by mobile browsers.
- Added best-effort vibration cues on devices that expose the web vibration API;
  iPhone browsers may ignore vibration while still playing the sound effects.
Scrobble 2.73
-------------
- Closed a move-validation loophole that allowed a valid connected word to be
  accepted while another newly placed tile sat beyond an empty gap in the same
  row or column.
- Every square between the outermost newly placed tiles must now be occupied by
  either a new tile or an existing board tile before dictionary validation,
  scoring, or opponent review can proceed.
- Invalid gapped layouts remain on the board for correction and show a clear
  "one continuous word" message; no partial word can be committed.
Scrobble 2.74
-------------
- Reworked the synthesized feedback palette to sound substantially more comic:
  exaggerated pitch bends, squeaks, boings, honks, rattles, vocal formants,
  wider musical jumps, and less restrained timing and volume.
- Added an original two-part puppet-style "woo-hoo" sound to the splash. It
  attempts to play during startup and waits for the first interaction when
  mobile Chrome blocks audio before a user gesture.
- Increased both curved splash-logo phrases by 2px at desktop and phone sizes.
Scrobble 2.75
-------------
- Rebuilt the Yay Everybody mascot as a reusable layered digital puppet rather
  than a single flattened circular image.
- The bright-blue portal, open-eye body, blink body, left arm, and right arm are
  independently controlled layers. Hair and fingertips extend beyond the portal
  onto the dark-blue background so the mascot appears to emerge through it.
- Added an entrance pop with two-arm waving on the splash, natural occasional
  idle blinks, tap-to-wave behavior, a valid-word wave, and a two-arm jumping
  celebration for scores of 25 or more and at game end.
- Exposed safe blink, wave, and celebrate animation hooks for future game events.
- Mascot animation remains isolated and honors reduced-motion preferences.

Scrobble 2.76: mascot arms resized and shoulder-anchored; waving/celebration now pivots from the shoulder sockets; facial animation enhanced with more natural single/double blinks plus subtle face bops.


Scrobble 2.79: rebuilt mascot two-arm rig with fixed shoulder sockets, slower blinking, and excited arm flail animation.

Scrobble 2.80: preserves the improved 2.79 shoulder geometry; arm movement now uses direct element animation to prevent flashing/disappearing, with a larger visible wave and excited Muppet-style ripple/flail.

Scrobble 2.81: mascot arm movement moved to dedicated shoulder-joint wrappers so legacy arm-image transforms cannot suppress motion. Splash now performs a clearly visible 1.75s two-arm excited flail after the blink; torso stays fixed and blink cadence remains unchanged.

Scrobble 2.83: arm animation rebuilt with direct Web Animations API; 30% shorter arms preserved; obvious splash wave plus excited floppy ripple.

Scrobble 2.84: sleeves and arms are a single shoulder-pivoting assembly; fixed sleeves removed; arms slightly thickened; excited motion uses traveling canvas deformation for a visible Kermit-style ripple rather than a broad wave.

Scrobble 2.85: integrated shoulder+sleeve into each arm, thicker arms, and slower/more dramatic traveling ripple.

Scrobble 2.86: thicker connected shoulder/sleeve/arm assemblies; deeper torso overlap; slower, much more dramatic traveling arm ripple.
SCROBBLE 3.13

- Multiplayer games now end immediately when the bag is empty and a player plays their final rack tile.
- The server marks the game completed before another turn can begin.
- Standard endgame scoring transfers the opponent's remaining rack value: it is deducted from the opponent and awarded to the finisher.
- The winner announcement and final-score overlay now appear for multiplayer games.
- Active games already stuck after a final-tile play are detected and repaired when the player with the empty rack opens the game.
- Run supabase_v3130_multiplayer_endgame.sql once before deploying this build.
SCROBBLE 3.14

- The game-over Rematch button now distinguishes friend games from computer games.
- A friend rematch creates a fresh game directly with the same opponent; no invitation link is required.
- The opponent receives the opening turn, matching the established invited-player-first behavior.
- Rematches preserve the original game's Make It Weird rules.
- Server-side rematch creation is idempotent, so both players cannot accidentally create duplicate rematches from the same completed game.
- Run supabase_v3140_friend_rematch.sql once before deploying this build.
