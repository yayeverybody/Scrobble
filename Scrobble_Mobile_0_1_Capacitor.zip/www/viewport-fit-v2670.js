(function(){
  'use strict';
  const root=document.getElementById('scrobble-v4');
  if(!root)return;
  const mobile=window.matchMedia('(max-width:760px) and (pointer:coarse)');
  let frame=0,measureFrame=0;

  function viewportHeight(){
    return Math.floor((window.visualViewport&&window.visualViewport.height)||window.innerHeight||document.documentElement.clientHeight);
  }

  function clearFit(){
    root.style.setProperty('--game-fit-scale','1');
    root.style.setProperty('--fit-small','0px');
    root.style.setProperty('--fit-medium','0px');
    root.style.setProperty('--fit-large','0px');
  }

  function fitGame(){
    cancelAnimationFrame(measureFrame);
    clearFit();
    if(!mobile.matches||!document.body.classList.contains('scrobbleGameActive')||root.hidden)return;
    measureFrame=requestAnimationFrame(function(){
      const available=Math.max(1,viewportHeight());
      const natural=Math.ceil(root.getBoundingClientRect().height);
      if(!natural)return;
      if(natural>available){
        const scale=Math.max(.68,Math.min(1,(available-1)/natural));
        root.style.setProperty('--game-fit-scale',scale.toFixed(4));
        return;
      }
      const unit=Math.max(0,(available-natural)/8.5);
      root.style.setProperty('--fit-small',(unit*.25).toFixed(2)+'px');
      root.style.setProperty('--fit-medium',(unit*.75).toFixed(2)+'px');
      root.style.setProperty('--fit-large',(unit*2.5).toFixed(2)+'px');
    });
  }

  function queueFit(){
    cancelAnimationFrame(frame);
    frame=requestAnimationFrame(fitGame);
  }

  new MutationObserver(queueFit).observe(document.body,{attributes:true,attributeFilter:['class']});
  window.addEventListener('resize',queueFit,{passive:true});
  window.addEventListener('orientationchange',queueFit,{passive:true});
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',queueFit,{passive:true});
  }
  if(mobile.addEventListener)mobile.addEventListener('change',queueFit);
  else if(mobile.addListener)mobile.addListener(queueFit);
  queueFit();
})();
