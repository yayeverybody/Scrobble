import webpush from "npm:web-push@3.6.7";
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors={"content-type":"application/json"};
Deno.serve(async(req)=>{
  if(req.method!=="POST")return new Response("Method not allowed",{status:405});
  if(req.headers.get("x-scrobble-secret")!==Deno.env.get("SCROBBLE_PUSH_SECRET"))return new Response("Unauthorized",{status:401});
  const {user_id,game_id,opponent_name}=await req.json();
  const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const {data:subs,error}=await supabase.from("scrobble_push_subscriptions").select("id,endpoint,p256dh,auth").eq("user_id",user_id);
  if(error)throw error;
  webpush.setVapidDetails(Deno.env.get("VAPID_SUBJECT")||"mailto:hello@yayeverybody.com",Deno.env.get("VAPID_PUBLIC_KEY")!,Deno.env.get("VAPID_PRIVATE_KEY")!);
  const payload=JSON.stringify({title:"Your turn in Scrobble!",body:`${opponent_name||"Your opponent"} played. It’s your move.`,url:`/?game=${encodeURIComponent(game_id)}`,tag:`scrobble-${game_id}`});
  for(const s of subs||[]){
    try{await webpush.sendNotification({endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},payload)}
    catch(e){if(e?.statusCode===404||e?.statusCode===410)await supabase.from("scrobble_push_subscriptions").delete().eq("id",s.id);else console.error(e)}
  }
  return new Response(JSON.stringify({ok:true,count:(subs||[]).length}),{headers:cors});
});
