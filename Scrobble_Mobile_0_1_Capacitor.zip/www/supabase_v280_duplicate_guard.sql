-- Scrobble 2.8 — database-level duplicate guard
-- Run once in Supabase SQL Editor.
--
-- The client already sends one stable invite_code for a pending friend game.
-- This index makes that code unique at the database level, so even two
-- simultaneous create requests cannot create two rows for the same invite.

do $$
begin
  if exists (
    select 1
    from public.games
    where invite_code is not null
    group by invite_code
    having count(*) > 1
  ) then
    raise exception
      'Duplicate invite_code rows already exist. End/delete those duplicate waiting games first, then run this migration again.';
  end if;
end $$;

create unique index if not exists scrobble_games_invite_code_unique
on public.games (invite_code)
where invite_code is not null;
