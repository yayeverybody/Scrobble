-- Scrobble 3.13 — authoritative multiplayer endgame handling
-- Run once against the Scrobble Supabase project.

create or replace function public.finish_scrobble_game(p_game_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
  g public.games%rowtype;
  finisher public.game_players%rowtype;
  opponent public.game_players%rowtype;
  deduction integer := 0;
  final_score_1 integer;
  final_score_2 integer;
  winner uuid;
begin
  if uid is null then raise exception 'Not signed in'; end if;
  if not exists (
    select 1 from public.game_players
    where game_id = p_game_id and player_id = uid
  ) then raise exception 'You are not in this game'; end if;

  select * into g from public.games where id = p_game_id for update;
  if g.id is null then raise exception 'Game not found'; end if;

  if g.status = 'completed' then
    return jsonb_build_object('ok',true,'completed',true,'deduction',0,
      'scores',jsonb_build_array(g.score_1,g.score_2));
  end if;
  if g.status <> 'active' then raise exception 'Game is not active'; end if;
  if jsonb_array_length(coalesce(g.bag,'[]'::jsonb)) <> 0 then
    raise exception 'The tile bag is not empty';
  end if;

  select * into finisher
  from public.game_players
  where game_id = p_game_id
    and jsonb_array_length(coalesce(rack,'[]'::jsonb)) = 0
  order by case when player_id = uid then 0 else 1 end, player_number
  limit 1;
  if finisher.game_id is null then raise exception 'No player has emptied their rack'; end if;

  select * into opponent from public.game_players
  where game_id = p_game_id and player_id <> finisher.player_id limit 1;
  if opponent.game_id is null then raise exception 'Opponent not found'; end if;

  select coalesce(sum(case value
    when 'A' then 1 when 'B' then 4 when 'C' then 4 when 'D' then 2
    when 'E' then 1 when 'F' then 4 when 'G' then 3 when 'H' then 3
    when 'I' then 1 when 'J' then 10 when 'K' then 5 when 'L' then 2
    when 'M' then 4 when 'N' then 2 when 'O' then 1 when 'P' then 4
    when 'Q' then 10 when 'R' then 1 when 'S' then 1 when 'T' then 1
    when 'U' then 2 when 'V' then 5 when 'W' then 4 when 'X' then 8
    when 'Y' then 3 when 'Z' then 10 else 0 end),0)::integer
  into deduction from jsonb_array_elements_text(coalesce(opponent.rack,'[]'::jsonb));

  final_score_1 := g.score_1;
  final_score_2 := g.score_2;
  if finisher.player_number = 1 then
    final_score_1 := final_score_1 + deduction;
    final_score_2 := final_score_2 - deduction;
  else
    final_score_2 := final_score_2 + deduction;
    final_score_1 := final_score_1 - deduction;
  end if;

  select player_id into winner from public.game_players
  where game_id = p_game_id
    and player_number = case when final_score_1 > final_score_2 then 1
                             when final_score_2 > final_score_1 then 2 else 0 end;

  update public.games set status='completed',current_player_id=finisher.player_id,
    score_1=final_score_1,score_2=final_score_2,winner_id=winner,
    challenge=null,updated_at=now()
  where id=p_game_id;

  return jsonb_build_object('ok',true,'completed',true,
    'finisher_slot',finisher.player_number,'deduction',deduction,
    'scores',jsonb_build_array(final_score_1,final_score_2),'winner_id',winner);
end;
$$;

revoke execute on function public.finish_scrobble_game(uuid) from public, anon;
grant execute on function public.finish_scrobble_game(uuid) to authenticated;

create or replace function public.save_scrobble_turn(
  p_game_id uuid,p_board jsonb,p_bag jsonb,p_score_1 integer,p_score_2 integer,
  p_rack jsonb,p_move_type text,p_words jsonb,p_points integer
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
  g public.games%rowtype;
  gp public.game_players%rowtype;
  opponent public.game_players%rowtype;
  next_player uuid;
  deduction integer := 0;
  final_score_1 integer := p_score_1;
  final_score_2 integer := p_score_2;
  winner uuid;
  finished boolean := false;
begin
  if uid is null then raise exception 'Not signed in'; end if;
  select * into g from public.games where id=p_game_id for update;
  if g.id is null then raise exception 'Game not found'; end if;
  if g.status <> 'active' then raise exception 'Game is not active'; end if;
  if g.current_player_id <> uid then raise exception 'It is not your turn'; end if;

  select * into gp from public.game_players
  where game_id=p_game_id and player_id=uid;
  if gp.game_id is null then raise exception 'You are not in this game'; end if;
  select * into opponent from public.game_players
  where game_id=p_game_id and player_id<>uid limit 1;
  if opponent.game_id is null then raise exception 'Your opponent has not joined yet'; end if;
  next_player := opponent.player_id;

  update public.game_players set rack=p_rack
  where game_id=p_game_id and player_id=uid;

  finished := p_move_type='play'
    and jsonb_array_length(coalesce(p_bag,'[]'::jsonb))=0
    and jsonb_array_length(coalesce(p_rack,'[]'::jsonb))=0;

  if finished then
    select coalesce(sum(case value
      when 'A' then 1 when 'B' then 4 when 'C' then 4 when 'D' then 2
      when 'E' then 1 when 'F' then 4 when 'G' then 3 when 'H' then 3
      when 'I' then 1 when 'J' then 10 when 'K' then 5 when 'L' then 2
      when 'M' then 4 when 'N' then 2 when 'O' then 1 when 'P' then 4
      when 'Q' then 10 when 'R' then 1 when 'S' then 1 when 'T' then 1
      when 'U' then 2 when 'V' then 5 when 'W' then 4 when 'X' then 8
      when 'Y' then 3 when 'Z' then 10 else 0 end),0)::integer
    into deduction from jsonb_array_elements_text(coalesce(opponent.rack,'[]'::jsonb));
    if gp.player_number=1 then
      final_score_1:=final_score_1+deduction;final_score_2:=final_score_2-deduction;
    else
      final_score_2:=final_score_2+deduction;final_score_1:=final_score_1-deduction;
    end if;
    select player_id into winner from public.game_players
    where game_id=p_game_id
      and player_number=case when final_score_1>final_score_2 then 1
                             when final_score_2>final_score_1 then 2 else 0 end;
  end if;

  update public.games set board=p_board,bag=p_bag,score_1=final_score_1,score_2=final_score_2,
    current_player_id=case when finished then uid else next_player end,
    status=case when finished then 'completed' else status end,
    winner_id=case when finished then winner else winner_id end,
    challenge=case when finished then null else challenge end,updated_at=now()
  where id=p_game_id;

  insert into public.game_moves(game_id,player_id,move_type,words,points,board_after)
  values(p_game_id,uid,p_move_type,coalesce(p_words,'[]'::jsonb),coalesce(p_points,0),p_board);

  return jsonb_build_object('ok',true,'completed',finished,
    'next_player_id',case when finished then null else next_player end,
    'finisher_slot',case when finished then gp.player_number else null end,
    'deduction',deduction,'scores',jsonb_build_array(final_score_1,final_score_2),
    'winner_id',winner);
end;
$$;

revoke execute on function public.save_scrobble_turn(uuid,jsonb,jsonb,integer,integer,jsonb,text,jsonb,integer) from public, anon;
grant execute on function public.save_scrobble_turn(uuid,jsonb,jsonb,integer,integer,jsonb,text,jsonb,integer) to authenticated;
