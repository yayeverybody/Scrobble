/* Scrobble 2.90 — hard replacement with supplied lower-right mascot. */
(()=>{'use strict';try{
const rigs=[],reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function build(host,kind){
 if(!host)return null;
 host.replaceChildren();
 host.className=host.className.replace(/\bmascotRigHost--\S+/g,'').trim();
 host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
 host.setAttribute('role','img');host.setAttribute('aria-label','Yay Everybody mascot');
 const rig=document.createElement('div');rig.className='mascotRig290';
 const base=document.createElement('img');base.className='mascotBase290';base.src='icons/yay-puppet-lower-right-v290.png?v=290';base.alt='';base.draggable=false;
 const lids=document.createElement('div');lids.className='mascotLids290';
 lids.innerHTML='<span class="lid290 lid290L"></span><span class="lid290 lid290R"></span>';
 rig.append(base,lids);host.appendChild(rig);rigs.push(rig);return rig;
}
function blink(r,d=false){if(!r||reduced||document.hidden)return;const c=()=>{r.classList.add('isBlinking');setTimeout(()=>r.classList.remove('isBlinking'),150)};c();if(d)setTimeout(c,260)}
function schedule(r){setTimeout(()=>{blink(r,Math.random()<.18);schedule(r)},2600+Math.random()*2200)}
const s=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
build(document.querySelector('#scrobble-v4 .yayButton'),'game');
rigs.forEach(schedule);if(s)setTimeout(()=>blink(s,true),700);
window.ScrobbleMascot={blink:()=>rigs.forEach(r=>blink(r,true)),wave:()=>{},celebrate:()=>{}};
}catch(e){console.warn('mascot 2.90',e)}})();