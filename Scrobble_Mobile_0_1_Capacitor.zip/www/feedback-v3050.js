/* Scrobble 3.05 — actual recorded sound effects only. */
(()=>{'use strict';try{
  const MASTER=.055;

  // Actual recorded source files. No synthesis or TTS.
  const SOURCES={
    // Human voice actor saying "Woohoo!" (OpenGameArt).
    ding:'https://freesound.org/data/previews/237/237105_2398403-lq.ogg?scrobble=305'
  };

  const audio={};
  for(const [name,src] of Object.entries(SOURCES)){
    const a=new Audio();
    a.preload='auto';
    a.playsInline=true;
    a.volume=MASTER;
    a.src=src;
    audio[name]=a;
  }

  let unlocked=false;
  function unlock(){
    if(unlocked)return;
    unlocked=true;
    for(const a of Object.values(audio)){try{a.load()}catch(_){}}
  }
  ['pointerdown','touchstart','keydown'].forEach(t=>
    document.addEventListener(t,unlock,{capture:true,passive:true})
  );

  function play(name,volume=MASTER){
    if(!unlocked)return;
    const a=audio[name]; if(!a)return;
    try{
      a.pause(); a.currentTime=0; a.volume=volume;
      const p=a.play(); p?.catch?.(()=>{});
    }catch(_){}
  }

  // Actual human woo-hoo when a word is successfully played.
  window.addEventListener('scrobble:turn-ended',e=>{
    const d=e.detail||{};
    if(d.move_type==='play')play('ding',MASTER);
  });

  // No startup ta-da. No slide whistle. No generated metallic effects.
}catch(e){console.warn('feedback 3.01',e)}})();
