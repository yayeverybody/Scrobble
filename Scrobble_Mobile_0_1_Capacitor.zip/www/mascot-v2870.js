/* Scrobble 2.87 — connected shoulder/sleeve/arm assemblies with simple up/down shoulder waving. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className; img.src=src; img.alt=alt; img.draggable=false;
      return img;
    }

    class ArmRenderer{
      constructor(canvas,src,side){
        this.canvas=canvas;
        this.ctx=canvas.getContext('2d');
        this.side=side;
        this.img=new Image();
        this.ready=false;
        this.raf=0;
        canvas.width=768; canvas.height=768;
        this.img.onload=()=>{this.ready=true;this.drawStatic();};
        this.img.src=src;
      }
      stop(){ if(this.raf) cancelAnimationFrame(this.raf); this.raf=0; this.drawStatic(); }
      drawStatic(){
        if(!this.ready)return;
        const c=this.ctx;c.clearRect(0,0,768,768);c.drawImage(this.img,0,0,768,768);
      }
      ripple(duration=2600,intensity=1){
        this.stop();
      }
    }

    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');
      host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');
      rig.className='mascotRig mascotRig284';
      rig.dataset.mascotKind=kind;
      const portal=document.createElement('div'); portal.className='mascotPortal';

      const leftJoint=document.createElement('div'); leftJoint.className='mascotArmJoint284 mascotArmJoint284--left';
      const rightJoint=document.createElement('div'); rightJoint.className='mascotArmJoint284 mascotArmJoint284--right';
      const leftCanvas=document.createElement('canvas'); leftCanvas.className='mascotArmCanvas284';
      const rightCanvas=document.createElement('canvas'); rightCanvas.className='mascotArmCanvas284';
      leftJoint.appendChild(leftCanvas); rightJoint.appendChild(rightCanvas);
      const leftRenderer=new ArmRenderer(leftCanvas,'icons/yay-puppet-arm-sleeve-v287.png','left');
      const rightRenderer=new ArmRenderer(rightCanvas,'icons/yay-puppet-arm-sleeve-right-v287.png','right');
      rig._armRenderers=[leftRenderer,rightRenderer];

      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-nosleeves-v284.png');
      const blinkImg=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-nosleeves-v284.png');
      rig.append(portal,leftJoint,rightJoint,body,blinkImg);
      host.appendChild(rig);
      rigs.push(rig);
      return rig;
    }

    function cancelJointAnimations(rig){
      rig.querySelectorAll('.mascotArmJoint284').forEach(el=>{try{el.getAnimations().forEach(a=>a.cancel())}catch(_){}});
    }

    // A normal wave is a true shoulder pivot: sleeve and arm rotate together as one piece.
    function shoulderWave(rig){
      if(!rig||reduced)return;
      cancelJointAnimations(rig);
      const l=rig.querySelector('.mascotArmJoint284--left');
      const r=rig.querySelector('.mascotArmJoint284--right');
      if(!l||!r)return;
      const o={duration:900,iterations:1,easing:'ease-in-out'};
      l.animate([{transform:'rotate(0deg)'},{transform:'rotate(-24deg)'},{transform:'rotate(12deg)'},{transform:'rotate(-8deg)'},{transform:'rotate(0deg)'}],o);
      r.animate([{transform:'rotate(0deg)'},{transform:'rotate(24deg)'},{transform:'rotate(-12deg)'},{transform:'rotate(8deg)'},{transform:'rotate(0deg)'}],o);
    }

    // Excited motion is deliberately NOT a broad wave. Shoulder stays nearly fixed while a traveling bend ripples to the hands.
    function excitedRipple(rig){
      if(!rig||reduced)return;
      cancelJointAnimations(rig);
      const l=rig.querySelector('.mascotArmJoint284--left');
      const r=rig.querySelector('.mascotArmJoint284--right');
      if(!l||!r)return;
      const framesL=[
        {transform:'rotate(0deg)'},{transform:'rotate(-34deg)'},{transform:'rotate(18deg)'},
        {transform:'rotate(-30deg)'},{transform:'rotate(14deg)'},{transform:'rotate(-24deg)'},
        {transform:'rotate(10deg)'},{transform:'rotate(0deg)'}
      ];
      const framesR=[
        {transform:'rotate(0deg)'},{transform:'rotate(34deg)'},{transform:'rotate(-18deg)'},
        {transform:'rotate(30deg)'},{transform:'rotate(-14deg)'},{transform:'rotate(24deg)'},
        {transform:'rotate(-10deg)'},{transform:'rotate(0deg)'}
      ];
      const o={duration:2600,iterations:1,easing:'ease-in-out'};
      l.animate(framesL,o); r.animate(framesR,o);
      window.dispatchEvent(new CustomEvent('scrobble:mascot-tada'));
    }

    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{rig.classList.add('isBlinking');setTimeout(()=>rig.classList.remove('isBlinking'),125);};
      close(); if(doubleBlink)setTimeout(close,260);
    }
    function scheduleBlink(rig){setTimeout(()=>{blink(rig,Math.random()<.14);scheduleBlink(rig)},7000+Math.random()*4000);}

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash){
      setTimeout(()=>blink(splash,true),900);
      // Show the new bend/ripple clearly on startup; tapping the mascot repeats it.
      setTimeout(()=>excitedRipple(splash),1450);
      splash.parentElement?.addEventListener('pointerdown',()=>excitedRipple(splash));
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>shoulderWave(rig)));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      Number(event.detail.points||0)>=25?excitedRipple(game):shoulderWave(game);
    });
    window.addEventListener('scrobble:game-over',()=>excitedRipple(game));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(r=>blink(r,true)),
      wave:()=>rigs.forEach(shoulderWave),
      celebrate:()=>rigs.forEach(excitedRipple)
    };
  }catch(e){console.warn('Mascot animation unavailable',e)}
})();
