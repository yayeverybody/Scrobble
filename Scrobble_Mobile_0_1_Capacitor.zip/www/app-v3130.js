(()=>{
  const SUPABASE_URL='https://wvjotzhjfllnttisrywh.supabase.co';
  const SUPABASE_PUBLISHABLE_KEY='sb_publishable_zphvbVT9Bt4QG8g7Up_fNA_KeuYieik';
  const dash=document.getElementById('scrobble-dashboard'), game=document.getElementById('scrobble-v4');
  const active=document.getElementById('activeGames'),completed=document.getElementById('completedGames'),statusEl=document.getElementById('cloudStatus');
  const inviteBox=document.getElementById('inviteBox'),inviteLinkEl=document.getElementById('inviteLink');
  const gameModeBox=document.getElementById('gameModeBox'),closeGameMode=document.getElementById('closeGameMode'),playFriendMode=document.getElementById('playFriendMode');
  const joinBox=document.getElementById('joinBox'),confirmJoin=document.getElementById('confirmJoin'),cancelJoin=document.getElementById('cancelJoin');
  const endGameBox=document.getElementById('endGameBox'),confirmEndGame=document.getElementById('confirmEndGame'),cancelEndGame=document.getElementById('cancelEndGame');
  const accountBox=document.getElementById('accountBox'),accountDash=document.getElementById('accountDash'),closeAccount=document.getElementById('closeAccount'),accountIdentity=document.getElementById('accountIdentity'),accountState=document.getElementById('accountState'),passwordAccountForm=document.getElementById('passwordAccountForm'),accountUsername=document.getElementById('accountUsername'),accountEmail=document.getElementById('accountEmail'),accountPassword=document.getElementById('accountPassword'),signInAccount=document.getElementById('signInAccount'),createAccount=document.getElementById('createAccount'),forgotPassword=document.getElementById('forgotPassword'),passwordSetupToggle=document.getElementById('passwordSetupToggle'),passwordSetupAccount=document.getElementById('passwordSetupAccount'),passwordSetupStatus=document.getElementById('passwordSetupStatus'),accountNewPassword=document.getElementById('accountNewPassword'),accountConfirmPassword=document.getElementById('accountConfirmPassword'),saveAccountPassword=document.getElementById('saveAccountPassword'),logoutAccount=document.getElementById('logoutAccount'),
  rulesWelcome=document.getElementById('rulesWelcome'),rulesWelcomeOk=document.getElementById('rulesWelcomeOk'),
  notifyTurnBox=document.getElementById('notifyTurnBox'),notifyTurnEnable=document.getElementById('notifyTurnEnable'),notifyTurnLater=document.getElementById('notifyTurnLater'),notifyTurnCopy=document.getElementById('notifyTurnCopy'),notifyTurnIosHelp=document.getElementById('notifyTurnIosHelp'),notifyTurnStatus=document.getElementById('notifyTurnStatus'),
  notificationSetupAccount=document.getElementById('notificationSetupAccount'),
  avatarAccountTools=document.getElementById('avatarAccountTools'),
  accountAvatarPreview=document.getElementById('accountAvatarPreview'),
  accountAvatarFile=document.getElementById('accountAvatarFile'),
  removeAccountAvatar=document.getElementById('removeAccountAvatar');
  let client=null,user=null,currentGame=null,currentSlot=null,currentComputer=false,lastGames=[],pendingJoinCode=null,pendingEndGameId=null,myProfile=null,selectedAvatarIcon='⭐',selectedAvatarUrl=null,uploadedAvatarFile=null,pendingNewGame=null;
  let cloudBoardRefreshPromise=null,currentCloudFingerprint=null,recoveringFinishedGame=false;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  let topResetTimer=null;
  function resetDocumentTop(){
    clearTimeout(topResetTimer);
    try{history.scrollRestoration='manual'}catch(e){}
    const reset=()=>{
      document.documentElement.scrollTop=0;
      document.body.scrollTop=0;
      window.scrollTo(0,0)
    };
    reset();
    requestAnimationFrame(()=>{
      reset();
      requestAnimationFrame(reset)
    });
    topResetTimer=setTimeout(reset,320)
  }
  function rulesSeenKey(){return user?.id?`scrobble-rules-seen:${user.id}`:null}
  function maybeShowRules(){
    const key=rulesSeenKey();
    if(!key||!rulesWelcome)return;
    try{if(localStorage.getItem(key)==='1')return}catch(e){}
    rulesWelcome.classList.remove('hidden')
  }
  function dismissRules(){
    const key=rulesSeenKey();
    if(key){try{localStorage.setItem(key,'1')}catch(e){}}
    rulesWelcome?.classList.add('hidden');
    setTimeout(maybeShowPushPrompt,350)
  }
  if(rulesWelcomeOk)rulesWelcomeOk.onclick=dismissRules;

  const PUSH_PUBLIC_KEY='BE0ebAF_m-o3sqoHUv-Hfi0G8oYfK5WB_0Mgl1JDgx5hnmdHcCz4obHfrUpcih7hvQigAIK6FVv7K3TKwYKYnzQ';
  let pushRegistration=null;
  function isIOS(){return /iphone|ipad|ipod/i.test(navigator.userAgent)}
  function isStandalone(){return window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true}
  function pushSeenKey(){return user?.id?`scrobble-push-prompt:${user.id}`:null}
  function urlBase64ToUint8Array(base64String){
    const padding='='.repeat((4-base64String.length%4)%4);
    const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');
    const raw=atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)))
  }
  async function registerScrobbleWorker(){
    if(!('serviceWorker' in navigator))throw new Error('This browser does not support background notifications.');
    if(!pushRegistration)pushRegistration=await navigator.serviceWorker.register('sw-v2610.js',{scope:'./'});
    await navigator.serviceWorker.ready;return pushRegistration
  }
  async function syncPushSubscription(subscription){
    if(!subscription||!user)return;
    const json=subscription.toJSON();
    await rpc('save_scrobble_push_subscription',{
      p_endpoint:subscription.endpoint,
      p_p256dh:json.keys?.p256dh||'',
      p_auth:json.keys?.auth||'',
      p_user_agent:navigator.userAgent||''
    })
  }
  async function ensurePushSubscription(requestPermission=false){
    const reg=await registerScrobbleWorker();
    let permission=Notification.permission;
    if(permission==='default'&&requestPermission)permission=await Notification.requestPermission();
    if(permission!=='granted')return null;
    let sub=await reg.pushManager.getSubscription();
    if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(PUSH_PUBLIC_KEY)});
    await syncPushSubscription(sub);return sub
  }
  function browserLabel(){
    const ua=navigator.userAgent||'';
    if(/CriOS/i.test(ua))return'Chrome';
    if(/EdgiOS|EdgA|Edg\//i.test(ua))return'Edge';
    if(/FxiOS|Firefox/i.test(ua))return'Firefox';
    if(/SamsungBrowser/i.test(ua))return'Samsung Internet';
    if(/Safari/i.test(ua)&&!/Chrome|CriOS|Edg|FxiOS/i.test(ua))return'Safari';
    if(/Chrome/i.test(ua))return'Chrome';
    return'Your browser'
  }
  function notificationSetupCopy(){
    const browser=browserLabel();
    if(isIOS()&&!isStandalone())return{
      copy:`On iPhone, ${browser} needs Scrobble added to your Home Screen before notifications can work.`,
      help:`<strong>${browser}:</strong> tap the <b>Share</b> button, choose <b>Add to Home Screen</b>, then tap <b>Add</b>. Open Scrobble from its new Home Screen icon, sign in, and choose <b>Turn On Notifications</b>.`,
      action:'SHOW ME HOW'
    };
    if(/Android/i.test(navigator.userAgent||'')&&!isStandalone())return{
      copy:'Turn on notifications so Scrobble can tell you when an opponent plays.',
      help:`<strong>${browser}:</strong> you can enable notifications now. For the best experience, use the browser menu to choose <b>Install app</b> or <b>Add to Home screen</b>.`,
      action:'TURN ON NOTIFICATIONS'
    };
    return{copy:'Get a notification when your opponent plays so games keep moving.',help:'',action:'TURN ON NOTIFICATIONS'}
  }
  function openNotificationSetup(ignoreSeen=false){
    if(!user||!notifyTurnBox)return;
    const key=pushSeenKey();
    if(!ignoreSeen){try{if(key&&localStorage.getItem(key)==='1')return}catch(e){}}
    const setup=notificationSetupCopy();
    notifyTurnCopy.textContent=setup.copy;
    notifyTurnIosHelp.innerHTML=setup.help;
    notifyTurnIosHelp.classList.toggle('hidden',!setup.help);
    notifyTurnEnable.textContent=setup.action;
    notifyTurnStatus.textContent='';
    notifyTurnBox.classList.remove('hidden')
  }
  async function maybeShowPushPrompt(){
    if(!user||!notifyTurnBox||!('Notification' in window)||!('serviceWorker' in navigator)||!('PushManager' in window))return;
    try{if(Notification.permission==='granted'){await ensurePushSubscription(false);return}}catch(e){console.warn('Push subscription refresh failed',e)}
    openNotificationSetup(false)
  }
  async function enableTurnNotifications(){
    if(isIOS()&&!isStandalone()){
      notifyTurnIosHelp.classList.remove('hidden');
      notifyTurnStatus.textContent='After adding it, open Scrobble from the Home Screen icon and tap Turn On Notifications.';
      return
    }
    notifyTurnEnable.disabled=true;notifyTurnStatus.textContent='Turning notifications on…';
    try{
      const sub=await ensurePushSubscription(true);
      if(!sub)throw new Error('Notifications were not allowed.');
      const key=pushSeenKey();if(key)try{localStorage.setItem(key,'1')}catch(e){}
      notifyTurnStatus.textContent='You’re all set. We’ll let you know when it’s your turn.';
      setTimeout(()=>notifyTurnBox.classList.add('hidden'),1000)
    }catch(e){notifyTurnStatus.textContent=e.message||'Could not turn notifications on.'}
    finally{notifyTurnEnable.disabled=false}
  }
  if(notifyTurnEnable)notifyTurnEnable.onclick=enableTurnNotifications;
  if(notifyTurnLater)notifyTurnLater.onclick=()=>{const key=pushSeenKey();if(key)try{localStorage.setItem(key,'1')}catch(e){};notifyTurnBox.classList.add('hidden')};
  if(notificationSetupAccount)notificationSetupAccount.onclick=()=>{accountBox.classList.add('hidden');openNotificationSetup(true)};

  function showGame(){
    document.body.classList.remove('scrobbleDashActive');
    document.body.classList.add('scrobbleGameActive');
    dash.hidden=true;
    game.hidden=false;
    resetDocumentTop()
  }
  function setAccountGate(required){
    accountBox.classList.toggle('requiredAccount',!!required);
    closeAccount.style.display=required?'none':'';
    accountBox.dataset.required=required?'1':'0';
    if(required){
      accountBox.classList.remove('hidden');
      document.querySelector('#accountBox .accountTitle').textContent='Create Your Scrobble Account';
      document.querySelector('#accountBox .accountSub').textContent='Create an account or sign in before you play so your games stay with you.';
    }else{
      document.querySelector('#accountBox .accountTitle').textContent='Your Scrobble Account';
      document.querySelector('#accountBox .accountSub').textContent='Your Scrobble account is tied to your email address.';
    }
  }
  function showDash(){
    document.body.classList.remove('scrobbleGameActive');
    if(!hasPermanentAccount(user)){
      document.body.classList.remove('scrobbleDashActive');
      dash.hidden=true;
      game.hidden=true;
      setAccountGate(true);
      return
    }
    document.body.classList.add('scrobbleDashActive');
    setAccountGate(false);
    game.hidden=true;
    dash.hidden=false;
    currentGame=null;
    currentSlot=null;
    currentComputer=false;
    currentCloudFingerprint=null;
    lastOpponentNoticeKey='';
    resetDocumentTop();
    Promise.resolve(refreshGames()).finally(resetDocumentTop)
  }
  window.addEventListener('scrobble:home',()=>{
    if(currentComputer){
      const rec=loadComputerRecord();
      if(rec){rec.state=window.ScrobbleGame.prepareForHome();rec.updated_at=new Date().toISOString();saveComputerRecord(rec)}
    }
    showDash()
  });
  function inviteURL(code){return location.origin+location.pathname+'?join='+encodeURIComponent(code)}
  function openInvite(code,newGameState=null){
    const url=inviteURL(code);
    inviteLinkEl.textContent=url;
    inviteBox.dataset.url=url;
    inviteBox.dataset.code=code;
    pendingNewGame=newGameState?{...newGameState,invite_code:code}:null;
    inviteBox.classList.remove('hidden')
  }
  function closeInviteBox(){inviteBox.classList.add('hidden');pendingNewGame=null}
  document.getElementById('closeInvite').onclick=closeInviteBox;
  let pendingCreatePromise=null;
  async function persistPendingNewGame(){
    if(!pendingNewGame)return pendingCreatePromise||null;
    if(pendingCreatePromise)return pendingCreatePromise;
    const ng=pendingNewGame;
    pendingNewGame=null;
    pendingCreatePromise=(async()=>{
      try{
        const existingRaw=await rpc('list_scrobble_games');
        const existingGames=Array.isArray(existingRaw)?existingRaw:[];
        const existing=existingGames.find(g=>String(g.invite_code||'')===String(ng.invite_code||''));
        if(existing){
          pendingNewGame=null;
          await refreshGames();
          return existing
        }
        const data=await rpc('create_scrobble_game',{
          p_board:ng.board,
          p_bag:ng.bag,
          p_rack:ng.racks[0],
          p_pending_rack:ng.racks[1],
          p_invite_code:ng.invite_code
        });
        if(data?.id&&Array.isArray(ng.weirdRules)&&ng.weirdRules.length){
          await rpc('set_scrobble_weird_rules',{p_game_id:data.id,p_rules:ng.weirdRules})
        }
        pendingNewGame=null;
        await refreshGames();
        return data
      }catch(e){
        if(!pendingNewGame)pendingNewGame=ng;
        throw e
      }finally{
        pendingCreatePromise=null
      }
    })();
    return pendingCreatePromise
  }
  document.getElementById('copyInvite').onclick=async()=>{
    const btn=document.getElementById('copyInvite');
    try{
      await navigator.clipboard.writeText(inviteBox.dataset.url);
      if(pendingNewGame)await persistPendingNewGame();
      btn.textContent='Copied!';setTimeout(()=>btn.textContent='Copy link',1200)
    }catch(e){
      if(!navigator.clipboard){
        prompt('Copy this link:',inviteBox.dataset.url)
      }else{
        alert('Could not copy the invite link: '+e.message)
      }
    }
  };
  document.getElementById('shareInvite').onclick=async()=>{
    if(navigator.share){
      try{
        await navigator.share({title:'Play Scrobble with me',text:'Join my Scrobble game:',url:inviteBox.dataset.url});
        if(pendingNewGame)await persistPendingNewGame()
      }catch(e){
        if(e&&e.name!=='AbortError')alert('Could not share the invite: '+e.message)
      }
    }else document.getElementById('copyInvite').click()
  };
  function code(){return Math.random().toString(36).slice(2,8).toUpperCase()+Math.random().toString(36).slice(2,6).toUpperCase()}
  async function rpc(name,args={}){const {data,error}=await client.rpc(name,args);if(error)throw error;return data}
  function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  function hasPermanentAccount(u){return !!(u&&u.id)&&u.is_anonymous!==true}
  function metadataUsername(u){return String(u?.user_metadata?.display_name||u?.user_metadata?.username||'').trim()}
  function accountDisplayName(u){return String(myProfile?.display_name||metadataUsername(u)||u?.email||'Scrobble Player').trim()}
  async function saveIdentityProfile(preferredDisplay=null){
    if(!user||!hasPermanentAccount(user))return null;
    const display=String(preferredDisplay||metadataUsername(user)||myProfile?.display_name||'').trim();
    if(!display)return null;
    const row={id:user.id,display_name:display,avatar_url:myProfile?.avatar_url||null,updated_at:new Date().toISOString()};
    const {data,error}=await client.from('profiles').upsert(row,{onConflict:'id'}).select().single();
    if(error)throw error;
    myProfile=data;
    return data;
  }
  function normalizeProfileRow(row){
    if(Array.isArray(row))row=row[0]||null;
    if(!row)return null;
    const display=String(row.display_name||row.username||row.name||'').trim();
    return {...row,display_name:display||null}
  }
  async function loadProfileById(id){
    if(!id)return null;
    try{
      const {data,error}=await client.from('profiles').select('id,display_name,avatar_url').eq('id',id).maybeSingle();
      if(!error&&data?.display_name)return normalizeProfileRow(data)
      if(error)console.warn('Direct profile lookup blocked for',id,error)
    }catch(e){
      console.warn('Direct profile lookup failed for',id,e)
    }
    try{
      const p=normalizeProfileRow(await rpc('get_scrobble_public_profile',{p_user_id:id}));
      if(p?.display_name)return p
    }catch(e){
      console.warn('Public profile RPC lookup failed for',id,e)
    }
    return null
  }
  async function loadMyProfile(){
    myProfile=await loadProfileById(user?.id);
    if(!myProfile){
      try{myProfile=normalizeProfileRow(await rpc('get_my_scrobble_profile'))}catch(e){myProfile=null}
    }
    if(!myProfile&&user&&hasPermanentAccount(user)&&metadataUsername(user)){
      try{await saveIdentityProfile(metadataUsername(user))}catch(e){console.warn('Could not create username profile',e)}
    }
    renderAccount();renderAccountButton();
  }
  function profileLabel(p,fallback='Player'){return p?.display_name||fallback}
  const opponentProfileCache=new Map();
  async function usernameProfileForGame(g){
    if(!g?.opponent_id)return null;
    const direct=g.opponent_profile||null;
    if(direct?.display_name){
      opponentProfileCache.set(g.opponent_id,direct);
      return direct
    }
    if(opponentProfileCache.has(g.opponent_id))return opponentProfileCache.get(g.opponent_id);

    const profile=await loadProfileById(g.opponent_id);
    if(profile?.display_name){
      opponentProfileCache.set(g.opponent_id,profile);
      return profile
    }

    try{
      const detail=await rpc('get_scrobble_game',{p_game_id:g.id});
      const slot=detail?.player_number;
      const fallbackProfile=slot===1?detail?.player2_profile:slot===2?detail?.player1_profile:null;
      if(fallbackProfile?.display_name){
        opponentProfileCache.set(g.opponent_id,fallbackProfile);
        return fallbackProfile
      }
    }catch(e){
      console.warn('Could not load opponent username for game',g.id,e)
    }
    return direct
  }
  function safeAvatarUrl(url){
    const s=String(url||'').trim();
    return /^https:\/\//i.test(s)?s:''
  }
  function avatarMarkup(p,fallback='P'){
    const url=safeAvatarUrl(p?.avatar_url);
    if(url)return `<img class="avatarPhoto" src="${esc(url)}" alt="" loading="lazy">`;
    const label=String(p?.display_name||fallback||'P').trim();
    return esc((label.charAt(0)||'P').toUpperCase());
  }
  function setGameAvatar(el,p,fallback){
    if(!el)return;
    const url=safeAvatarUrl(p?.avatar_url);
    el.classList.toggle('hasImage',!!url);
    el.style.backgroundImage=url?`url("${url.replace(/"/g,'%22')}")`:'';
    const label=String(p?.display_name||fallback||'P').trim();
    el.textContent=url?'':(label.charAt(0)||'P').toUpperCase();
  }
  function renderAccountAvatar(){
    if(!accountAvatarPreview)return;
    const url=safeAvatarUrl(myProfile?.avatar_url);
    const label=accountDisplayName(user)||'P';
    accountAvatarPreview.innerHTML=url?`<img src="${esc(url)}" alt="Your profile photo">`:esc((label.charAt(0)||'P').toUpperCase());
    removeAccountAvatar.classList.toggle('hidden',!url)
  }
  async function resizeAvatarFile(file){
    if(!file)throw new Error('No photo selected.');
    if(file.size>25*1024*1024)throw new Error('That photo is unusually large. Please choose a different one.');
    const url=URL.createObjectURL(file);
    try{
      const img=await new Promise((resolve,reject)=>{
        const el=new Image();
        el.onload=()=>resolve(el);
        el.onerror=()=>reject(new Error('Scrobble could not read that photo.'));
        el.src=url
      });
      const sourceW=img.naturalWidth||img.width;
      const sourceH=img.naturalHeight||img.height;
      if(!sourceW||!sourceH)throw new Error('Scrobble could not read that photo.');
      const side=Math.min(sourceW,sourceH);
      const sx=Math.max(0,(sourceW-side)/2);
      const sy=Math.max(0,(sourceH-side)/2);
      const target=512;
      const canvas=document.createElement('canvas');
      canvas.width=target;
      canvas.height=target;
      const ctx=canvas.getContext('2d',{alpha:false});
      if(!ctx)throw new Error('Scrobble could not prepare that photo.');
      ctx.drawImage(img,sx,sy,side,side,0,0,target,target);
      const blob=await new Promise((resolve,reject)=>{
        canvas.toBlob(b=>b?resolve(b):reject(new Error('Scrobble could not resize that photo.')),'image/jpeg',0.84)
      });
      return blob
    }finally{
      URL.revokeObjectURL(url)
    }
  }
  async function uploadAccountAvatar(file){
    if(!user||!hasPermanentAccount(user))return;
    if(!file)return;
    accountAvatarFile.disabled=true;
    try{
      const resized=await resizeAvatarFile(file);
      const path=`${user.id}/avatar-${Date.now()}.jpg`;
      const {error:upError}=await client.storage.from('avatars').upload(path,resized,{cacheControl:'3600',upsert:false,contentType:'image/jpeg'});
      if(upError)throw upError;
      const {data:urlData}=client.storage.from('avatars').getPublicUrl(path);
      const avatar_url=urlData?.publicUrl;
      if(!avatar_url)throw new Error('Could not create the profile-photo URL.');
      const previous=myProfile?.avatar_url||null;
      const display=accountDisplayName(user);
      const {data,error}=await client.from('profiles').upsert({id:user.id,display_name:display,avatar_url,updated_at:new Date().toISOString()},{onConflict:'id'}).select().single();
      if(error)throw error;
      myProfile=normalizeProfileRow(data);
      opponentProfileCache.clear();
      renderAccountAvatar();
      await refreshGames();
      if(previous&&previous!==avatar_url){
        try{
          const marker='/storage/v1/object/public/avatars/';
          const oldPath=decodeURIComponent(previous.split(marker)[1]||'');
          if(oldPath.startsWith(user.id+'/'))await client.storage.from('avatars').remove([oldPath])
        }catch(e){}
      }
    }catch(e){alert('Could not upload profile photo: '+e.message)}
    finally{accountAvatarFile.value='';accountAvatarFile.disabled=false}
  }
  async function removeMyAvatar(){
    if(!user||!myProfile?.avatar_url)return;
    const old=myProfile.avatar_url;
    try{
      const {data,error}=await client.from('profiles').update({avatar_url:null,updated_at:new Date().toISOString()}).eq('id',user.id).select().single();
      if(error)throw error;
      myProfile=normalizeProfileRow(data);
      renderAccountAvatar();
      await refreshGames();
      try{
        const marker='/storage/v1/object/public/avatars/';
        const oldPath=decodeURIComponent(old.split(marker)[1]||'');
        if(oldPath.startsWith(user.id+'/'))await client.storage.from('avatars').remove([oldPath])
      }catch(e){}
    }catch(e){alert('Could not remove profile photo: '+e.message)}
  }
  function renderAccountButton(){if(accountDash){accountDash.textContent='ACCOUNT';accountDash.classList.remove('signedInAccount')}}
  function renderAccount(){
    const permanent=hasPermanentAccount(user);
    if(permanent){
      const display=accountDisplayName(user);
      accountIdentity.classList.remove('hidden');
      accountIdentity.innerHTML=`<strong>${esc(display)}</strong><span>${esc(user?.email||'')}</span>`;
      avatarAccountTools.classList.remove('hidden');renderAccountAvatar();
      accountState.textContent='';accountState.style.display='none';
      passwordAccountForm.classList.add('hidden');
      passwordSetupToggle.classList.remove('hidden');
      notificationSetupAccount.classList.remove('hidden');
      logoutAccount.classList.remove('hidden');
    }else{
      accountIdentity.classList.add('hidden');accountIdentity.innerHTML='';avatarAccountTools.classList.add('hidden');
      accountState.textContent='Sign in, or choose a username to create a new account.';accountState.style.display='';
      passwordAccountForm.classList.remove('hidden');
      passwordSetupToggle.classList.add('hidden');passwordSetupAccount.classList.add('hidden');
      notificationSetupAccount.classList.add('hidden');
      logoutAccount.classList.add('hidden');
    }
    renderAccountButton();
  }
  accountAvatarFile.addEventListener('change',()=>uploadAccountAvatar(accountAvatarFile.files?.[0]));
  removeAccountAvatar.addEventListener('click',removeMyAvatar);
  async function openAccount(){await loadMyProfile();renderAccountAvatar();accountBox.classList.remove('hidden')}
  function openPasswordSetup(recovery=false){
    renderAccount();accountBox.classList.remove('hidden');passwordSetupAccount.classList.remove('hidden');
    passwordSetupToggle.textContent='HIDE PASSWORD SETUP';
    passwordSetupStatus.textContent=recovery?'Your reset link worked. Choose a new password below.':'Use this password to sign in from the Home Screen app or another browser.';
    passwordSetupStatus.classList.remove('success','error');
    setTimeout(()=>accountNewPassword.focus(),120)
  }
  accountDash.onclick=openAccount;
  closeAccount.onclick=()=>{if(accountBox.dataset.required!=='1')accountBox.classList.add('hidden')};
  accountBox.addEventListener('click',e=>{if(e.target===accountBox&&accountBox.dataset.required!=='1')accountBox.classList.add('hidden')});
  passwordSetupToggle.onclick=()=>{
    const opening=passwordSetupAccount.classList.contains('hidden');
    passwordSetupAccount.classList.toggle('hidden',!opening);
    passwordSetupToggle.textContent=opening?'HIDE PASSWORD SETUP':'SET / CHANGE PASSWORD';
    if(opening)setTimeout(()=>accountNewPassword.focus(),120)
  };
  saveAccountPassword.onclick=async()=>{
    const password=accountNewPassword.value,confirmation=accountConfirmPassword.value;
    passwordSetupStatus.classList.remove('success','error');
    if(password.length<8){passwordSetupStatus.textContent='Password must be at least 8 characters.';passwordSetupStatus.classList.add('error');return}
    if(password!==confirmation){passwordSetupStatus.textContent='The two passwords do not match.';passwordSetupStatus.classList.add('error');return}
    saveAccountPassword.disabled=true;const old=saveAccountPassword.textContent;saveAccountPassword.textContent='SAVING…';
    try{
      const {error}=await client.auth.updateUser({password});if(error)throw error;
      accountNewPassword.value='';accountConfirmPassword.value='';
      passwordSetupStatus.textContent='Password saved. You can now use it to sign in from the Home Screen app.';passwordSetupStatus.classList.add('success')
    }catch(e){passwordSetupStatus.textContent='Could not save password: '+e.message;passwordSetupStatus.classList.add('error')}
    finally{saveAccountPassword.disabled=false;saveAccountPassword.textContent=old}
  };

  logoutAccount.onclick=async()=>{
    logoutAccount.disabled=true;
    logoutAccount.textContent='LOGGING OUT…';
    try{
      const {error}=await client.auth.signOut();
      if(error)throw error;
      location.reload();
    }catch(e){
      alert('Could not log out: '+e.message);
      logoutAccount.disabled=false;
      logoutAccount.textContent='LOG OUT';
    }
  };

  function authCredentials(){
    const email=accountEmail.value.trim().toLowerCase();
    const password=accountPassword.value;
    if(!email){alert('Enter your email address.');return null}
    if(!password){alert('Enter your password.');return null}
    if(password.length<6){alert('Password must be at least 6 characters.');return null}
    return {email,password};
  }
  function newAccountUsername(){
    const username=accountUsername.value.trim();
    if(!username){alert('Choose a username for your Scrobble account.');return null}
    if(!/^[A-Za-z0-9_]{3,20}$/.test(username)){alert('Username must be 3–20 letters, numbers, or underscores.');return null}
    return username;
  }
  async function finishPasswordAuth(data,preferredUsername=null){
    if(!data?.session?.user)throw new Error('No signed-in session was returned. If email confirmation is enabled in Supabase, turn Confirm Email off for the launch flow.');
    user=data.session.user;window.ScrobbleCloudUser=user;
    setAccountGate(false);accountBox.classList.add('hidden');
    if(preferredUsername){
      try{await saveIdentityProfile(preferredUsername)}catch(e){console.warn('Username profile save failed',e)}
    }
    try{await loadMyProfile()}catch(e){console.warn('Profile load failed',e)}
    statusEl.textContent='Signed in as '+String(user?.email||accountDisplayName(user));
    statusEl.style.color='#237a2b';statusEl.style.background='#eaf7eb';
    showDash();
    try{await joinFromURL()}catch(e){console.warn('Invite join failed',e)}
    if(preferredUsername)setTimeout(()=>openNotificationSetup(true),550)
  }
  signInAccount.onclick=async()=>{
    const credentials=authCredentials();if(!credentials)return;
    signInAccount.disabled=true;const old=signInAccount.textContent;signInAccount.textContent='SIGNING IN…';
    try{
      const {data,error}=await client.auth.signInWithPassword(credentials);
      if(error)throw error;
      await finishPasswordAuth(data);
    }catch(e){alert('Could not sign in: '+e.message)}
    finally{signInAccount.disabled=false;signInAccount.textContent=old}
  };
  createAccount.onclick=async()=>{
    const username=newAccountUsername();if(!username)return;
    const credentials=authCredentials();if(!credentials)return;
    createAccount.disabled=true;const old=createAccount.textContent;createAccount.textContent='CREATING…';
    try{
      const {data,error}=await client.auth.signUp({...credentials,options:{data:{display_name:username,username}}});
      if(error)throw error;
      if(!data?.session){
        alert('Account created, but Supabase is requiring email confirmation. For the simplest launch, turn Confirm Email OFF in Authentication → Providers → Email, then try again.');
        return;
      }
      await finishPasswordAuth(data,username);
    }catch(e){alert('Could not create account: '+e.message)}
    finally{createAccount.disabled=false;createAccount.textContent=old}
  };
  forgotPassword.onclick=async()=>{
    const email=accountEmail.value.trim().toLowerCase();
    if(!email){alert('Enter your email address first.');return}
    forgotPassword.disabled=true;
    try{
      const redirect=new URL(location.origin+location.pathname);redirect.searchParams.set('password-recovery','1');
      const {error}=await client.auth.resetPasswordForEmail(email,{redirectTo:redirect.href});
      if(error)throw error;
      alert('Password reset email sent. Open its link, then choose and save your new password in Scrobble.');
    }catch(e){alert('Could not send password reset email: '+e.message)}
    finally{forgotPassword.disabled=false}
  };



  const CPU_ACTIVE_KEY='scrobble-cpu-active-v1',CPU_DONE_KEY='scrobble-cpu-completed-v1';
  function loadComputerRecord(){try{return JSON.parse(localStorage.getItem(CPU_ACTIVE_KEY)||'null')}catch(e){return null}}
  function saveComputerRecord(rec){try{localStorage.setItem(CPU_ACTIVE_KEY,JSON.stringify(rec))}catch(e){}}
  function loadCompletedComputerGames(){try{return JSON.parse(localStorage.getItem(CPU_DONE_KEY)||'[]')||[]}catch(e){return[]}}
  function saveCompletedComputerGames(list){try{localStorage.setItem(CPU_DONE_KEY,JSON.stringify(list.slice(0,12)))}catch(e){}}
  function computerDifficultyLabel(d){return d==='hard'?'Hard':d==='easy'?'Easy':'Medium'}
  const WEIRD_LABELS={
    all_or_none:'All or None',
    too_many_ts:'All or None',
    vowel_movement:'Vowel Movement',
    high_roller:'High Roller',
    too_many_tiles:'Too Many Tiles',
    seven_heaven:'Too Many Tiles',
    oops_all_ys:'Oops! All Y’s'
  };
  function selectedWeirdRules(){return [...gameModeBox.querySelectorAll('.weirdChoice input:checked')].map(x=>x.value)}
  gameModeBox.querySelectorAll('.weirdChoice input').forEach(input=>input.addEventListener('change',()=>{if(input.checked)gameModeBox.querySelectorAll('.weirdChoice input').forEach(other=>{if(other!==input)other.checked=false})}));
  function clearWeirdRules(){gameModeBox.querySelectorAll('.weirdChoice input').forEach(x=>x.checked=false)}
  function weirdRuleList(rules){return (Array.isArray(rules)?rules:[]).map(r=>WEIRD_LABELS[r]).filter(Boolean)}
  function saveCurrentComputerGame(){
    if(!currentComputer)return;
    const rec=loadComputerRecord();if(!rec)return;
    rec.state=window.ScrobbleGame.exportState();rec.score_1=rec.state.scores?.[0]||0;rec.score_2=rec.state.scores?.[1]||0;rec.updated_at=new Date().toISOString();saveComputerRecord(rec)
  }
  async function openComputerGame(){
    const rec=loadComputerRecord();if(!rec)return;
    currentGame=null;currentSlot=1;currentComputer=true;
    window.ScrobbleGame.loadComputerState(rec.state,rec.difficulty);
    game.scrollIntoView({block:'start',inline:'nearest'});
    const me=accountDisplayName(user)||'You';
    document.getElementById('name1').textContent=me;
    document.getElementById('name2').textContent='Computer';
    setGameAvatar(document.getElementById('avatar1'),myProfile||{display_name:me},'Y');
    setGameAvatar(document.getElementById('avatar2'),{display_name:'Computer'},'C');
    showGame();
    if((rec.state?.current||0)===0&&rec.state?.lastMoveSummary?.playedBy===1){
      setTimeout(()=>window.ScrobbleGame.showTurnNotice(rec.state.lastMoveSummary),180)
    }
    if((rec.state?.current||0)===1)setTimeout(()=>window.ScrobbleGame.runComputerTurn(rec.difficulty),350)
  }
  function createComputerGame(difficulty){
    const weird=selectedWeirdRules();
    window.ScrobbleGame.newComputerGame(difficulty,weird);
    const state=window.ScrobbleGame.exportState(),rec={
      id:'cpu-'+Date.now(),status:'active',difficulty,weirdRules:weird,state,
      score_1:0,score_2:0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()
    };
    saveComputerRecord(rec);clearWeirdRules();gameModeBox.classList.add('hidden');openComputerGame()
  }
  function completeComputerGame(){
    const rec=loadComputerRecord();if(!rec)return;
    const state=currentComputer?window.ScrobbleGame.exportState():rec.state;
    const done={...rec,status:'completed',state,score_1:state?.scores?.[0]||0,score_2:state?.scores?.[1]||0,updated_at:new Date().toISOString()};
    const list=loadCompletedComputerGames();list.unshift(done);saveCompletedComputerGames(list);
    localStorage.removeItem(CPU_ACTIVE_KEY);currentComputer=false
  }

  async function createGame(){
    if(!user)return;
    const btn=document.getElementById('newGameDash');btn.disabled=true;
    try{
      const weird=selectedWeirdRules();
      window.ScrobbleGame.newGame(weird);
      const state=window.ScrobbleGame.exportState(),invite=code();
      openInvite(invite,state);clearWeirdRules()
    }catch(e){alert('Could not prepare game: '+e.message)}finally{btn.disabled=false}
  }
  document.getElementById('newGameDash').onclick=()=>gameModeBox.classList.remove('hidden');
  closeGameMode.onclick=()=>gameModeBox.classList.add('hidden');
  gameModeBox.addEventListener('click',e=>{if(e.target===gameModeBox)gameModeBox.classList.add('hidden')});
  playFriendMode.onclick=()=>{gameModeBox.classList.add('hidden');createGame()};
  gameModeBox.querySelectorAll('[data-cpu-difficulty]').forEach(btn=>btn.onclick=()=>createComputerGame(btn.dataset.cpuDifficulty));
  function askEndGame(id){pendingEndGameId=id;endGameBox.classList.remove('hidden')}
  function closeEndGame(){pendingEndGameId=null;endGameBox.classList.add('hidden')}
  cancelEndGame.onclick=closeEndGame;
  endGameBox.addEventListener('click',e=>{if(e.target===endGameBox)closeEndGame()});
  confirmEndGame.onclick=async()=>{
    if(!pendingEndGameId)return;
    const id=pendingEndGameId;confirmEndGame.disabled=true;confirmEndGame.textContent='Ending…';
    try{
      if(String(id).startsWith('cpu-'))completeComputerGame();
      else await rpc('end_scrobble_game',{p_game_id:id});
      closeEndGame();await refreshGames()
    }
    catch(e){alert('Could not end game: '+e.message)}
    finally{confirmEndGame.disabled=false;confirmEndGame.textContent='End Game'}
  };
  let lastGamesFingerprint='';
  const gameDetailCache=new Map();

  async function gameDisplayDetail(g){
    if(!g?.id)return null;
    if(gameDetailCache.has(g.id))return gameDetailCache.get(g.id);
    try{
      const detail=await rpc('get_scrobble_game',{p_game_id:g.id});
      gameDetailCache.set(g.id,detail||null);
      return detail||null
    }catch(e){
      console.warn('Could not load game player names',g.id,e);
      return null
    }
  }

  function currentUsername(){
    return accountDisplayName(user)||profileLabel(myProfile,'You')
  }

  function detailProfilesForMe(detail){
    if(!detail)return {me:null,opponent:null};
    const slot=detail.player_number;
    if(slot===1)return {me:detail.player1_profile||myProfile||null,opponent:detail.player2_profile||null};
    if(slot===2)return {me:detail.player2_profile||myProfile||null,opponent:detail.player1_profile||null};
    return {me:myProfile||null,opponent:null}
  }

  async function namesForGame(g){
    if(!g?.opponent_id)return {me:currentUsername(),opponent:'Waiting for Player 2',opponentProfile:null};
    const oppProfile=await usernameProfileForGame(g);
    if(!myProfile?.display_name&&user?.id){
      const refreshedMe=await loadProfileById(user.id);
      if(refreshedMe?.display_name)myProfile=refreshedMe
    }
    const me=profileLabel(myProfile,currentUsername());
    const opponent=profileLabel(oppProfile,'Opponent');
    return {me,opponent,opponentProfile:oppProfile}
  }

  function dedupeGameRows(list){
    const seen=new Set(),out=[];
    for(const g of (Array.isArray(list)?list:[])){
      const sig=[
        g.status||'',
        Number(g.score_1||0),
        Number(g.score_2||0),
        String(g.updated_at||'').slice(0,19)
      ].join('|');
      if(seen.has(sig))continue;
      seen.add(sig);
      out.push(g)
    }
    return out
  }

  async function quietRefreshGames(){
    if(!client||!user||gamesRefreshPromise)return;
    try{
      const games=await rpc('list_scrobble_games');
      const list=dedupeGameRows(games);
      const fingerprint=JSON.stringify(list.map(g=>[
        g.id,g.status,g.updated_at,g.current_player_id,g.score_1,g.score_2,
        g.opponent_id,g.opponent_profile?.display_name||'',!!g.challenge
      ]));
      if(fingerprint===lastGamesFingerprint)return;
      await refreshGames(list)
    }catch(e){
      console.warn('Quiet Games refresh failed',e)
    }
  }

  let gamesRefreshPromise=null;
  async function refreshGames(prefetchedGames=null){
    if(!client||!user)return;
    if(gamesRefreshPromise)return gamesRefreshPromise;
    gamesRefreshPromise=(async()=>{
      try{
        return await renderGamesSnapshot(prefetchedGames)
      }finally{
        gamesRefreshPromise=null
      }
    })();
    return gamesRefreshPromise
  }

  async function renderGamesSnapshot(prefetchedGames=null){
    if(!client||!user)return;
    try{
      opponentProfileCache.clear();
      const games=prefetchedGames||await rpc('list_scrobble_games');
      lastGames=dedupeGameRows(games);
      lastGamesFingerprint=JSON.stringify(lastGames.map(g=>[
        g.id,g.status,g.updated_at,g.current_player_id,g.score_1,g.score_2,
        g.opponent_id,g.opponent_profile?.display_name||'',!!g.challenge
      ]));
      active.innerHTML='';completed.innerHTML='';
      const a=lastGames.filter(g=>g.status==='active'),c=lastGames.filter(g=>g.status==='completed'),cpu=loadComputerRecord(),cpuDone=loadCompletedComputerGames();
      if(!a.length&&!cpu)active.innerHTML='<div class="empty">No active games yet. Start one to play.</div>';
      if(!c.length&&!cpuDone.length)completed.innerHTML='<div class="empty">No completed games yet.</div>';
      if(cpu){
        const wrap=document.createElement('div');wrap.className='gameCardWrap';
        const card=document.createElement('button');card.type='button';card.className='gameCard';
        const st=cpu.state||{},mine=(st.current||0)===0;
        card.innerHTML=`<div class="gameIdentity"><div class="oppAvatar">C</div><div class="gameInfo"><div class="opponent">Computer</div><div class="${mine?'turn':'turn their'}"><span class="turnDot"></span>${mine?'YOUR TURN':'THEIR TURN'}</div><div class="gameMeta">${formatGameTimestamp(cpu.updated_at)}</div></div></div><div class="gameDifficulty">${computerDifficultyLabel(cpu.difficulty).toUpperCase()}</div><div class="gameScores"><div class="scoreSide"><strong>${st.scores?.[0]||0}</strong><span>You</span></div><div class="scoreDivider"></div><div class="scoreSide"><strong>${st.scores?.[1]||0}</strong><span>Computer</span></div><div class="gameChevron">›</div></div>`;
        card.onclick=openComputerGame;
        const end=document.createElement('button');end.type='button';end.className='endGameBtn';end.setAttribute('aria-label','End game');end.title='End game';end.innerHTML='<span aria-hidden="true">×</span>';end.onclick=e=>{e.stopPropagation();askEndGame(cpu.id)};
        wrap.append(card,end);active.appendChild(wrap)
      }
      for(const g of a){
        const wrap=document.createElement('div');wrap.className='gameCardWrap';
        const card=document.createElement('button');card.type='button';card.className='gameCard';
        const waiting=!g.opponent_id;const mine=g.current_player_id===user.id;
        const review=!!g.challenge&&mine;const label=waiting?'WAITING FOR OPPONENT':review?'REVIEW WORD':mine?'YOUR TURN':'THEIR TURN';const cls=waiting?'turn wait':review?'turn':mine?'turn':'turn their';
        const names=await namesForGame(g);
        const oppProfile=names.opponentProfile||g.opponent_profile||null;
        const matchup=waiting?`${names.me} vs Waiting for Player 2`:`${names.me} vs ${names.opponent}`;
        card.innerHTML=`<div class="gameIdentity"><div class="oppAvatar">${waiting?'?':avatarMarkup(oppProfile)}</div><div class="gameInfo"><div class="opponent">${waiting?'Waiting for Player 2':esc(names.opponent)}</div><div class="${cls}"><span class="turnDot"></span>${label}</div>${waiting?'<div class="inviteMini">Tap to share invite</div>':''}<div class="gameMeta">${formatGameTimestamp(g.updated_at)}</div></div></div><div class="gameScores"><div class="scoreSide"><strong>${g.score_1||0}</strong></div><div class="scoreDivider"></div><div class="scoreSide"><strong>${g.score_2||0}</strong></div><div class="gameChevron">›</div></div>`;
        card.onclick=()=>waiting?openInvite(g.invite_code):openCloudGame(g.id);
        const end=document.createElement('button');end.type='button';end.className='endGameBtn';end.setAttribute('aria-label','End game');end.title='End game';end.innerHTML='<span aria-hidden="true">×</span>';
        end.onclick=e=>{e.stopPropagation();askEndGame(g.id)};
        wrap.append(card,end);active.appendChild(wrap)
      }
      for(const g of cpuDone){
        const el=document.createElement('div');el.className='gameCard';
        el.innerHTML=`<div class="gameIdentity"><div class="oppAvatar">C</div><div class="gameInfo"><div class="opponent">Computer</div><div class="turn completedTurn"><span class="turnDot"></span>COMPLETED</div><div class="gameMeta">${formatGameTimestamp(g.updated_at)}</div></div></div><div class="gameDifficulty">${computerDifficultyLabel(g.difficulty).toUpperCase()}</div><div class="gameScores"><div class="scoreSide"><strong>${g.score_1||0}</strong><span>You</span></div><div class="scoreDivider"></div><div class="scoreSide"><strong>${g.score_2||0}</strong><span>Computer</span></div><div class="completedCheck">✓</div></div>`;
        completed.appendChild(el)
      }
      for(const g of c){
        const el=document.createElement('div');el.className='gameCard';
        const names=await namesForGame(g);
        const oppProfile=names.opponentProfile||g.opponent_profile||null;
        const matchup=g.opponent_id?`${names.me} vs ${names.opponent}`:`${names.me} • Completed game`;
        el.innerHTML=`<div class="gameIdentity"><div class="oppAvatar">${avatarMarkup(oppProfile)}</div><div class="gameInfo"><div class="opponent">${esc(names.opponent)}</div><div class="turn completedTurn"><span class="turnDot"></span>COMPLETED</div><div class="gameMeta">${formatGameTimestamp(g.updated_at)}</div></div></div><div class="gameScores"><div class="scoreSide"><strong>${g.score_1||0}</strong></div><div class="scoreDivider"></div><div class="scoreSide"><strong>${g.score_2||0}</strong></div><div class="completedCheck">✓</div></div>`;
        completed.appendChild(el)
      }
    }catch(e){console.error(e);active.innerHTML='<div class="empty">Could not load games: '+e.message+'</div>'}
  }

  async function hydrateLeaderboardNames(rows){
    return Promise.all((rows||[]).map(async row=>{
      const current=String(row?.display_name||'').trim();
      if(current&&current.toLowerCase()!=='player')return row;
      const profile=await loadProfileById(row?.player_id);
      return {...row,display_name:profileLabel(profile,current||'Player')}
    }))
  }
  function leaderboardRows(rows,valueKey,label){
    if(!rows?.length)return '<div class="leaderboardEmpty">No completed multiplayer games yet.</div>';
    return rows.map((row,i)=>`<div class="leaderboardRow"><div class="leaderboardRank">${i+1}</div><div class="leaderboardName">${esc(row.display_name||'Player')}</div><div class="leaderboardValue">${Number(row[valueKey]||0).toLocaleString()} ${label}</div></div>`).join('')
  }
  function highestWordRows(rows){
    if(!rows?.length)return '<div class="leaderboardEmpty">No scored multiplayer words yet.</div>';
    return rows.map((row,i)=>`<div class="leaderboardRow highestWordRow"><div class="leaderboardRank">${i+1}</div><div class="leaderboardName"><strong>${esc(row.display_name||'Player')}</strong><span class="leaderboardWord">${esc(String(row.word||'').toUpperCase())}</span></div><div class="leaderboardValue">${Number(row.points||0).toLocaleString()} pts</div></div>`).join('')
  }
  async function openLeaderboards(){
    const box=document.getElementById('leaderboardBox');
    const status=document.getElementById('leaderboardStatus');
    const words=document.getElementById('wordsLeaderboard');
    const wins=document.getElementById('winsLeaderboard');
    const points=document.getElementById('pointsLeaderboard');
    box.classList.remove('hidden');status.textContent='Loading leaderboards…';words.innerHTML='';wins.innerHTML='';points.innerHTML='';
    try{
      const data=await rpc('get_scrobble_leaderboards',{p_limit:25});
      const wordRows=await hydrateLeaderboardNames(data?.highest_words||[]);
      const winsRows=await hydrateLeaderboardNames(data?.wins||[]);
      const pointsRows=await hydrateLeaderboardNames(data?.points||[]);
      words.innerHTML=highestWordRows(wordRows);
      wins.innerHTML=leaderboardRows(winsRows,'wins','wins');
      points.innerHTML=leaderboardRows(pointsRows,'points','pts');
      status.textContent='Completed multiplayer games • all time'
    }catch(e){
      status.textContent='Leaderboards need the Scrobble 2.23 Supabase migration.';
      words.innerHTML='<div class="leaderboardEmpty">Run supabase_v2380_highest_words.sql in Supabase, then reopen this screen.</div>';
      wins.innerHTML='';
      points.innerHTML=''
    }
  }
  document.getElementById('leaderboardDash').onclick=openLeaderboards;
  document.getElementById('closeLeaderboard').onclick=()=>document.getElementById('leaderboardBox').classList.add('hidden');
  document.getElementById('leaderboardBox').addEventListener('click',e=>{if(e.target.id==='leaderboardBox')e.currentTarget.classList.add('hidden')});

  function formatGameTimestamp(value){
    const d=new Date(value);
    if(Number.isNaN(d.getTime()))return '';
    const age=Date.now()-d.getTime();
    const withinPastWeek=age>=0&&age<(7*24*60*60*1000);
    const datePart=withinPastWeek
      ? d.toLocaleDateString(undefined,{weekday:'long'})
      : d.toLocaleDateString();
    const timePart=d.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'});
    return `${datePart}, ${timePart}`
  }

  let lastOpponentNoticeKey='';
  function maybeShowOpponentLastMove(state,slot){
    const lm=state?.lastMoveSummary;
    if(!lm||!slot)return;
    const opponentIndex=slot===1?1:0;
    const myTurn=(state.current_slot===slot-1);
    if(myTurn&&lm.playedBy===opponentIndex){
      const noticeKey=[currentGame||'',state.updated_at||'',lm.playedBy,lm.points||0,JSON.stringify(lm.words||[])].join('|');
      if(noticeKey===lastOpponentNoticeKey)return;
      lastOpponentNoticeKey=noticeKey;
      const root=document.getElementById('scrobble-v4');
      const fallback=opponentIndex===0?root?.querySelector('#name1')?.textContent:root?.querySelector('#name2')?.textContent;
      const summary={...lm,playerName:lm.playerName||fallback||'Opponent'};
      setTimeout(()=>window.ScrobbleGame.showTurnNotice(summary),180)
    }
  }

  function cloudStateFingerprint(s){
    if(!s)return '';
    return JSON.stringify([
      s.updated_at||'',
      s.current_player_id||'',
      s.current_slot,
      s.score_1??s.scores?.[0]??0,
      s.score_2??s.scores?.[1]??0,
      s.challenge||null,
      s.lastMoveSummary||null,
      s.board||null,
      s.rack||null
    ])
  }

  function applyCloudBoardState(s,{showLastMove=true}={}){
    if(!s||!currentSlot)return;
    window.ScrobbleGame.loadCloudState(s,currentSlot);
    window.ScrobbleGame.setSpectator(s.current_player_id!==user.id||!!s.challenge);
    currentCloudFingerprint=cloudStateFingerprint(s);
    if(showLastMove)maybeShowOpponentLastMove(s,currentSlot);
    if(s.challenge&&s.current_player_id===user.id){
      window.ScrobbleGame.showCloudChallenge(s.challenge)
    }
  }

  async function recoverFinishedCloudGame(s){
    if(recoveringFinishedGame||!currentGame||!currentSlot||s?.status!=='active'||s?.challenge)return false;
    if((s?.bag||[]).length!==0||(s?.rack||[]).length!==0)return false;
    recoveringFinishedGame=true;
    try{
      statusEl.textContent='Finishing game…';
      const result=await rpc('finish_scrobble_game',{p_game_id:currentGame});
      window.ScrobbleGame.finishCloudGame((Number(result?.finisher_slot)||currentSlot)-1,result?.deduction||0,result?.scores||s?.scores||[0,0]);
      await refreshGames();
      statusEl.textContent='Cloud connected • '+(accountDisplayName(user)||profileLabel(myProfile,'Player'));
      return true
    }catch(e){
      console.warn('Could not recover finished game',e);
      return false
    }finally{recoveringFinishedGame=false}
  }

  async function refreshCurrentCloudGame(force=false){
    if(!client||!user||!currentGame||currentComputer||game.hidden)return;
    if(cloudBoardRefreshPromise)return cloudBoardRefreshPromise;
    const gameId=currentGame;
    cloudBoardRefreshPromise=(async()=>{
      try{
        const s=await rpc('get_scrobble_game',{p_game_id:gameId});
        if(gameId!==currentGame||game.hidden)return;
        const fingerprint=cloudStateFingerprint(s);
        if(!force&&fingerprint===currentCloudFingerprint)return;
        applyCloudBoardState(s,{showLastMove:true});
        await recoverFinishedCloudGame(s);
        statusEl.textContent='Cloud connected • '+(accountDisplayName(user)||profileLabel(myProfile,'Player'))
      }catch(e){
        console.warn('Cloud board refresh failed',e)
      }finally{
        cloudBoardRefreshPromise=null
      }
    })();
    return cloudBoardRefreshPromise
  }

  async function openCloudGame(id){
    currentComputer=false;
    try{
      const s=await rpc('get_scrobble_game',{p_game_id:id});
      currentGame=id;currentSlot=s.player_number;
      applyCloudBoardState(s,{showLastMove:true});
      if(!myProfile?.display_name)myProfile=await loadProfileById(user?.id)||myProfile;
      const liveMe={...(myProfile||{}),display_name:accountDisplayName(user)||(myProfile?.display_name||null)};
      let p1=s.player1_profile||null,p2=s.player2_profile||null;
      const gameRow=lastGames.find(g=>g.id===id);
      const oppProfile=gameRow?await usernameProfileForGame(gameRow):null;
      if(currentSlot===1){p1=liveMe;if(!p2?.display_name&&oppProfile)p2=oppProfile}
      if(currentSlot===2){p2=liveMe;if(!p1?.display_name&&oppProfile)p1=oppProfile}
      document.getElementById('name1').textContent=profileLabel(p1,'Player 1');
      document.getElementById('name2').textContent=profileLabel(p2,'Player 2');
      setGameAvatar(document.getElementById('avatar1'),p1,'J');
      setGameAvatar(document.getElementById('avatar2'),p2,'S');
      showGame();
      await recoverFinishedCloudGame(s);
    }catch(e){alert('Could not open game: '+e.message)}
  }
  async function joinFromURL(){
    const u=new URL(location.href),join=u.searchParams.get('join');if(!join)return;
    pendingJoinCode=join.toUpperCase();
    const weirdEl=document.getElementById('joinWeirdness');
    weirdEl.classList.add('hidden');weirdEl.innerHTML='';
    try{
      const info=await rpc('get_scrobble_invite_weirdness',{p_invite_code:pendingJoinCode});
      const labels=weirdRuleList(info?.rules);
      if(labels.length){
        const who=esc(info?.creator_name||'Your opponent');
        weirdEl.innerHTML=`<div class="joinWeirdTitle">MAKE IT WEIRD</div><div class="joinWeirdWho">${who} is making this game weird with:</div><ul>${labels.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`;
        weirdEl.classList.remove('hidden')
      }
    }catch(e){console.warn('Could not load weird game rules',e)}
    joinBox.classList.remove('hidden');
  }
  async function confirmJoinGame(){
    if(!pendingJoinCode||!user)return;
    confirmJoin.disabled=true;confirmJoin.textContent='Joining…';
    try{
      const data=await rpc('join_scrobble_game',{p_invite_code:pendingJoinCode});
      const u=new URL(location.href);u.searchParams.delete('join');history.replaceState({},'',u.pathname+(u.search||''));
      joinBox.classList.add('hidden');statusEl.textContent='Game joined • Cloud connected';
      const joinedId=data&&data.id;pendingJoinCode=null;await refreshGames();
      try{if(Notification.permission==='granted')await ensurePushSubscription(false)}catch(e){console.warn('Push sync after join failed',e)}
      if(joinedId)await openCloudGame(joinedId);
    }catch(e){alert('Could not join game: '+e.message)}
    finally{confirmJoin.disabled=false;confirmJoin.textContent='Join Game'}
  }
  confirmJoin.onclick=confirmJoinGame;
  cancelJoin.onclick=()=>{joinBox.classList.add('hidden')};
  window.addEventListener('scrobble:game-over',e=>{
    if(!currentComputer)return;
    const rec=loadComputerRecord();
    window.__scrobbleLastCpuDifficulty=e.detail?.difficulty||rec?.difficulty||'medium';
    completeComputerGame()
  });
  window.addEventListener('scrobble:rematch',e=>{
    const difficulty=e.detail?.difficulty||window.__scrobbleLastCpuDifficulty||'medium';
    currentComputer=false;
    const rec=loadComputerRecord();
    const preserved=rec?.weirdRules||rec?.state?.weirdRules||[];
    gameModeBox.querySelectorAll('.weirdChoice input').forEach(x=>x.checked=preserved.includes(x.value));
    createComputerGame(difficulty)
  });

  window.addEventListener('scrobble:turn-ended',async e=>{
    if(currentComputer){
      saveCurrentComputerGame();
      const rec=loadComputerRecord();
      if(rec&&e.detail?.playedBy===0)setTimeout(()=>window.ScrobbleGame.runComputerTurn(rec.difficulty),6000);
      return
    }
    if(!currentGame||!currentSlot)return;
    try{
      statusEl.textContent='Saving turn…';const s=window.ScrobbleGame.exportState();
      const saved=await rpc('save_scrobble_turn',{p_game_id:currentGame,p_board:s.board,p_bag:s.bag,p_score_1:s.scores[0],p_score_2:s.scores[1],p_rack:s.racks[currentSlot-1],p_move_type:e.detail.move_type,p_words:e.detail.words||[],p_points:e.detail.points||0});
      if(e.detail.move_type==='play'&&(e.detail.words||[]).length===1){
        try{await rpc('record_scrobble_word_play',{p_game_id:currentGame,p_words:e.detail.words||[],p_points:e.detail.points||0})}catch(wordErr){console.warn('Highest-word record failed',wordErr)}
      }
      if(saved?.completed){
        window.ScrobbleGame.finishCloudGame((Number(saved.finisher_slot)||currentSlot)-1,saved.deduction||0,saved.scores||s.scores);
        await refreshGames()
      }else{
        await sleep(250);await refreshCurrentCloudGame(true)
      }
      statusEl.textContent='Cloud connected • '+(accountDisplayName(user)||profileLabel(myProfile,'Player'))
    }catch(err){alert('Turn was not saved: '+err.message);statusEl.textContent='Cloud save problem • '+err.message}
  });
  window.addEventListener('scrobble:challenge-created',async e=>{
    if(currentComputer){
      const w=e.detail?.review_word||'That word';
      window.ScrobbleGame.rejectPending(`Computer denied ${w}. Try another word.`);
      return
    }
    if(!currentGame||!currentSlot)return;
    try{
      statusEl.textContent='Sending word for review…';
      const d=e.detail||{};
      await rpc('submit_scrobble_challenge',{p_game_id:currentGame,p_words:d.words||[],p_review_word:d.review_word||'',p_points:d.points||0,p_candidate_board:d.candidate_board,p_candidate_bag:d.candidate_bag,p_candidate_rack:d.candidate_rack,p_score_1:d.candidate_scores?.[0]||0,p_score_2:d.candidate_scores?.[1]||0});
      await sleep(250);await refreshCurrentCloudGame(true);statusEl.textContent='Cloud connected • '+(accountDisplayName(user)||profileLabel(myProfile,'Player'))
    }catch(err){alert('Word review was not saved: '+err.message);statusEl.textContent='Cloud save problem • '+err.message}
  });
  window.addEventListener('scrobble:challenge-resolve',async e=>{
    if(!currentGame)return;
    try{
      statusEl.textContent=e.detail?.accept?'Accepting word…':'Denying word…';
      await rpc('resolve_scrobble_challenge',{p_game_id:currentGame,p_accept:!!e.detail?.accept});
      await sleep(250);await refreshCurrentCloudGame(true);statusEl.textContent='Cloud connected • '+(accountDisplayName(user)||profileLabel(myProfile,'Player'))
    }catch(err){alert('Could not resolve word: '+err.message);statusEl.textContent='Cloud save problem • '+err.message}
  });
  async function boot(){
    const splash=document.getElementById('scrobbleSplash');const splashStarted=Date.now();
    const recoveryRequested=new URL(location.href).searchParams.get('password-recovery')==='1'||/(?:^|[&#])type=recovery(?:&|$)/.test(location.hash);
    let authResolved=false;
    let enterGamesPromise=null;
    let enteredUserId=null;
    async function enterGames(session){
      if(!session?.user)return false;
      const incomingId=session.user.id;
      if(authResolved&&enteredUserId===incomingId)return true;
      if(enterGamesPromise)return enterGamesPromise;
      enterGamesPromise=(async()=>{
        user=session.user;window.ScrobbleCloudUser=user;
        enteredUserId=incomingId;
        setAccountGate(false);accountBox.classList.add('hidden');
        try{await loadMyProfile()}catch(e){console.warn('Profile load failed',e)}
        try{await saveIdentityProfile()}catch(e){console.warn('Identity profile sync failed',e)}
        authResolved=true;
        statusEl.textContent='Signed in as '+String(user?.email||accountDisplayName(user)||'Scrobble player');
        statusEl.style.color='#237a2b';statusEl.style.background='#eaf7eb';
        showDash();
        maybeShowRules();
        setTimeout(()=>{if(rulesWelcome?.classList.contains('hidden'))maybeShowPushPrompt()},900);
        try{await joinFromURL()}catch(e){console.warn('Invite join failed',e)}
        try{const gid=new URL(location.href).searchParams.get('game');if(gid){history.replaceState({},'',location.pathname);await openCloudGame(gid)}}catch(e){console.warn('Notification game open failed',e)}
        return true;
      })();
      try{return await enterGamesPromise}
      finally{enterGamesPromise=null}
    }
    function enterLogin(){
      if(authResolved)return;
      document.body.classList.remove('scrobbleDashActive','scrobbleGameActive');
      user=null;window.ScrobbleCloudUser=null;myProfile=null;
      renderAccountButton();
      statusEl.textContent='Sign in to continue';
      statusEl.style.color='#237a2b';statusEl.style.background='#eaf7eb';
      dash.hidden=true;game.hidden=true;setAccountGate(true);
    }
    try{
      client=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY,{
        auth:{
          persistSession:true,
          autoRefreshToken:true,
          detectSessionInUrl:true,
          flowType:'pkce',
          storage:window.localStorage,
          storageKey:'sb-wvjotzhjfllnttisrywh-auth-token'
        }
      });
      window.ScrobbleSupabase=client;

      // Bootstrap from exactly one source. Register the auth listener only
      // after the initial session has been resolved so INITIAL_SESSION/SIGNED_IN
      // cannot race the startup path.
      const {data,error}=await client.auth.getSession();
      if(error)throw error;
      if(data?.session?.user){
        await enterGames(data.session);
        if(recoveryRequested)setTimeout(()=>openPasswordSetup(true),250);
      }else{
        enterLogin();
      }

      let signedOutCheck=null;
      client.auth.onAuthStateChange((event,newSession)=>{
        if(event==='SIGNED_OUT'){
          clearTimeout(signedOutCheck);
          // A sleeping phone, spotty connection, or concurrent refresh can
          // briefly emit SIGNED_OUT. Recheck storage before showing the gate.
          signedOutCheck=setTimeout(async()=>{
            const {data}=await client.auth.getSession();
            if(data?.session?.user){await enterGames(data.session);return}
            authResolved=false;enteredUserId=null;enterLogin()
          },1400);
          return
        }
        clearTimeout(signedOutCheck);
        if(!newSession?.user)return;
        if(event==='PASSWORD_RECOVERY'){
          queueMicrotask(async()=>{await enterGames(newSession);openPasswordSetup(true)});return
        }
        if(authResolved&&enteredUserId===newSession.user.id)return;
        queueMicrotask(()=>enterGames(newSession))
      });

      const splashDelay=Math.max(0,4150-(Date.now()-splashStarted));
      setTimeout(()=>{
        splash.classList.add('hide');
        document.body.classList.remove('scrobbleSplashActive');
        resetDocumentTop()
      },splashDelay);
      window.addEventListener('pageshow',()=>{
        resetDocumentTop();
        client.auth.startAutoRefresh?.()
      });
      setInterval(()=>{if(user&&!dash.hidden)quietRefreshGames()},30000);
      setInterval(()=>{if(user&&!game.hidden&&currentGame&&!currentComputer)refreshCurrentCloudGame(false)},5000);
      document.addEventListener('visibilitychange',()=>{
        if(document.hidden){client.auth.stopAutoRefresh?.();return}
        client.auth.startAutoRefresh?.();
        resetDocumentTop();
        if(user&&!dash.hidden)refreshGames();
        if(user&&!game.hidden&&currentGame&&!currentComputer)refreshCurrentCloudGame(true)
      });
    }catch(e){
      console.error('Scrobble auth boot failed',e);
      statusEl.textContent='Sign-in error: '+e.message;
      statusEl.style.color='#9a4f00';statusEl.style.background='#fff3df';
      dash.hidden=true;game.hidden=true;setAccountGate(true);
      setTimeout(()=>{
        splash.classList.add('hide');
        document.body.classList.remove('scrobbleSplashActive');
        resetDocumentTop()
      },Math.max(0,4150-(Date.now()-splashStarted)));
    }
  }

  boot();
})();
