(function(){
  'use strict';

  function enhancePassword(input){
    if(!input||input.dataset.visibilityReady==='1')return;
    input.dataset.visibilityReady='1';
    const wrapper=document.createElement('div');
    wrapper.className='passwordField';
    input.parentNode.insertBefore(wrapper,input);
    wrapper.appendChild(input);

    const button=document.createElement('button');
    button.type='button';
    button.className='passwordReveal';
    button.textContent='SHOW';
    button.setAttribute('aria-controls',input.id);
    button.setAttribute('aria-label','Show password');
    button.setAttribute('aria-pressed','false');
    button.addEventListener('click',function(){
      const showing=input.type==='text';
      input.type=showing?'password':'text';
      button.textContent=showing?'SHOW':'HIDE';
      button.setAttribute('aria-label',showing?'Show password':'Hide password');
      button.setAttribute('aria-pressed',showing?'false':'true');
      input.focus({preventScroll:true});
      const end=input.value.length;
      try{input.setSelectionRange(end,end)}catch(e){}
    });
    wrapper.appendChild(button);
  }

  document.querySelectorAll('input[type="password"]').forEach(enhancePassword);
})();
