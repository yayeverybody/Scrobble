-- Scrobble 2.56 — Web Push Vault configuration
-- Run after supabase_v2550_web_push.sql and after deploying the Edge Function.

select vault.create_secret(
  'https://wvjotzhjfllnttisrywh.supabase.co/functions/v1/super-worker',
  'scrobble_push_url'
);

select vault.create_secret(
  'NKJomZUPpK71yCJ-8ZxyYQTxmQI9AZ4oh7lnyWA5rXzCs8orPuJwK1A9yO_DlUCS',
  'scrobble_push_secret'
);

create or replace function public.scrobble_queue_turn_push()
returns trigger
language plpgsql
security definer
set search_path=public,extensions,vault
as $$
declare
  actor uuid:=auth.uid();
  recipient uuid;
  actor_name text;
  payload jsonb;
  edge_url text;
  edge_secret text;
begin
  if new.status <> 'active'
     or new.current_player_id is null then
    return new;
  end if;

  if old.current_player_id
     is not distinct from new.current_player_id then
    return new;
  end if;

  recipient := new.current_player_id;

  if actor is not null and actor = recipient then
    return new;
  end if;

  select coalesce(p.display_name,'Your opponent')
  into actor_name
  from public.profiles p
  where p.id = actor;

  select decrypted_secret
  into edge_url
  from vault.decrypted_secrets
  where name = 'scrobble_push_url'
  limit 1;

  select decrypted_secret
  into edge_secret
  from vault.decrypted_secrets
  where name = 'scrobble_push_secret'
  limit 1;

  payload := jsonb_build_object(
    'user_id',recipient,
    'game_id',new.id,
    'opponent_name',coalesce(actor_name,'Your opponent')
  );

  if coalesce(edge_url,'') <> ''
     and coalesce(edge_secret,'') <> '' then
    perform net.http_post(
      url := edge_url,
      headers := jsonb_build_object(
        'Content-Type','application/json',
        'x-scrobble-secret',edge_secret
      ),
      body := payload
    );
  end if;

  return new;
end;
$$;
