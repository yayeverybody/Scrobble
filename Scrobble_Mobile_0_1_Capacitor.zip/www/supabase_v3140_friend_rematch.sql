-- Scrobble 3.14 — direct, idempotent friend rematches
-- Run once against the Scrobble Supabase project.

alter table public.games
  add column if not exists rematch_of uuid references public.games(id);

create unique index if not exists games_one_rematch_per_game_idx
  on public.games(rematch_of)
  where rematch_of is not null;

create or replace function public.create_scrobble_rematch(
  p_game_id uuid,
  p_board jsonb,
  p_bag jsonb,
  p_rack jsonb,
  p_opponent_rack jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
  old_game public.games%rowtype;
  opponent_id uuid;
  new_game_id uuid;
  caller_slot smallint;
begin
  if uid is null then raise exception 'Not signed in'; end if;

  select * into old_game
  from public.games
  where id=p_game_id
  for update;

  if old_game.id is null then raise exception 'Completed game not found'; end if;
  if old_game.status <> 'completed' then raise exception 'Finish this game before starting a rematch'; end if;

  select player_number into caller_slot
  from public.game_players
  where game_id=p_game_id and player_id=uid;
  if caller_slot is null then raise exception 'You are not in this game'; end if;

  select g.id into new_game_id
  from public.games g
  where g.rematch_of=p_game_id
  limit 1;
  if new_game_id is not null then
    select player_number into caller_slot
    from public.game_players
    where game_id=new_game_id and player_id=uid;
    return jsonb_build_object('id',new_game_id,'player_number',caller_slot,'existing',true);
  end if;

  select player_id into opponent_id
  from public.game_players
  where game_id=p_game_id and player_id<>uid
  limit 1;
  if opponent_id is null then raise exception 'Opponent not found'; end if;

  if jsonb_typeof(p_board)<>'array' or jsonb_typeof(p_bag)<>'array'
     or jsonb_typeof(p_rack)<>'array' or jsonb_typeof(p_opponent_rack)<>'array' then
    raise exception 'Invalid rematch game state';
  end if;

  insert into public.games(
    status,current_player_id,board,bag,score_1,score_2,
    invite_code,pending_rack,challenge,weird_rules,rematch_of
  ) values(
    'active',opponent_id,p_board,p_bag,0,0,
    null,null,null,coalesce(old_game.weird_rules,'[]'::jsonb),p_game_id
  ) returning id into new_game_id;

  insert into public.game_players(game_id,player_id,player_number,rack)
  values
    (new_game_id,uid,1,p_rack),
    (new_game_id,opponent_id,2,p_opponent_rack);

  return jsonb_build_object('id',new_game_id,'player_number',1,'existing',false);
end;
$$;

revoke execute on function public.create_scrobble_rematch(uuid,jsonb,jsonb,jsonb,jsonb)
  from public, anon;
grant execute on function public.create_scrobble_rematch(uuid,jsonb,jsonb,jsonb,jsonb)
  to authenticated;
