/* Scrobble 2.80 — stable visible arm motion using direct element animation; fixed shoulder sockets, natural blink. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className; img.src=src; img.alt=alt; img.draggable=false;
      return img;
    }
    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');
      host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');
      rig.className='mascotRig mascotRig279';
      rig.dataset.mascotKind=kind;
      const portal=document.createElement('div'); portal.className='mascotPortal';
      const left=layer('mascotArm279 mascotArm279--left','icons/yay-puppet-arm-v275.png');
      const right=layer('mascotArm279 mascotArm279--right','icons/yay-puppet-arm-right-v279.png');
      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-v275.png');
      const blinkImg=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-v275.png');
      rig.append(portal,left,right,body,blinkImg);
      host.appendChild(rig);
      rigs.push(rig);
      return rig;
    }
    function animateArms(rig,mode='wave'){
      if(!rig||reduced)return;
      const left=rig.querySelector('.mascotArm279--left');
      const right=rig.querySelector('.mascotArm279--right');
      if(!left||!right)return;
      try{ left.getAnimations().forEach(a=>a.cancel()); right.getAnimations().forEach(a=>a.cancel()); }catch(_){}

      const waveL=[
        {transform:'rotate(0deg)'},
        {transform:'rotate(-24deg)',offset:.25},
        {transform:'rotate(16deg)',offset:.52},
        {transform:'rotate(-12deg)',offset:.76},
        {transform:'rotate(0deg)'}
      ];
      const waveR=[
        {transform:'rotate(0deg)'},
        {transform:'rotate(24deg)',offset:.25},
        {transform:'rotate(-16deg)',offset:.52},
        {transform:'rotate(12deg)',offset:.76},
        {transform:'rotate(0deg)'}
      ];
      const excitedL=[
        {transform:'rotate(0deg) skewY(0deg)'},
        {transform:'rotate(-28deg) skewY(7deg)',offset:.10},
        {transform:'rotate(19deg) skewY(-8deg)',offset:.20},
        {transform:'rotate(-23deg) skewY(7deg)',offset:.30},
        {transform:'rotate(21deg) skewY(-7deg)',offset:.40},
        {transform:'rotate(-18deg) skewY(6deg)',offset:.50},
        {transform:'rotate(17deg) skewY(-6deg)',offset:.60},
        {transform:'rotate(-13deg) skewY(5deg)',offset:.70},
        {transform:'rotate(12deg) skewY(-4deg)',offset:.80},
        {transform:'rotate(-7deg) skewY(2deg)',offset:.90},
        {transform:'rotate(0deg) skewY(0deg)'}
      ];
      const excitedR=[
        {transform:'rotate(0deg) skewY(0deg)'},
        {transform:'rotate(28deg) skewY(-7deg)',offset:.10},
        {transform:'rotate(-19deg) skewY(8deg)',offset:.20},
        {transform:'rotate(23deg) skewY(-7deg)',offset:.30},
        {transform:'rotate(-21deg) skewY(7deg)',offset:.40},
        {transform:'rotate(18deg) skewY(-6deg)',offset:.50},
        {transform:'rotate(-17deg) skewY(6deg)',offset:.60},
        {transform:'rotate(13deg) skewY(-5deg)',offset:.70},
        {transform:'rotate(-12deg) skewY(4deg)',offset:.80},
        {transform:'rotate(7deg) skewY(-2deg)',offset:.90},
        {transform:'rotate(0deg) skewY(0deg)'}
      ];
      const excited=mode==='excited';
      const opts={duration:excited?1450:1050,easing:excited?'ease-in-out':'cubic-bezier(.35,.05,.3,1)',iterations:1,fill:'none'};
      left.animate(excited?excitedL:waveL,opts);
      right.animate(excited?excitedR:waveR,opts);
    }
    function pulse(rig,name,duration){
      if(!rig||reduced)return;
      if(name==='isWave279'){ animateArms(rig,'wave'); return; }
      if(name==='isExcited279'){ animateArms(rig,'excited'); return; }
      rig.classList.remove(name); void rig.offsetWidth; rig.classList.add(name);
      setTimeout(()=>rig.classList.remove(name),duration);
    }
    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{
        rig.classList.add('isBlinking');
        setTimeout(()=>rig.classList.remove('isBlinking'),125);
      };
      close();
      if(doubleBlink)setTimeout(close,260);
    }
    function scheduleBlink(rig){
      const next=7000+Math.random()*4000;
      setTimeout(()=>{
        blink(rig,Math.random()<.14);
        scheduleBlink(rig);
      },next);
    }

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash&&!reduced){
      setTimeout(()=>blink(splash,true),1500);
      setTimeout(()=>pulse(splash,'isExcited279',1500),2400);
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>pulse(rig,'isWave279',900)));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      const pts=Number(event.detail.points||0);
      pulse(game,pts>=25?'isExcited279':'isWave279',pts>=25?1500:900);
    });
    window.addEventListener('scrobble:game-over',()=>pulse(game,'isExcited279',1800));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(r=>blink(r,true)),
      wave:()=>rigs.forEach(r=>pulse(r,'isWave279',900)),
      celebrate:()=>rigs.forEach(r=>pulse(r,'isExcited279',1500))
    };
  }catch(_){/* mascot must never interfere with gameplay */}
})();
