/* Scrobble 2.92 — original aligned image-swap blink; one welcome wave only. */
(()=>{'use strict';try{
const rigs=[],reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function image(c,s){const e=document.createElement('img');e.className=c;e.src=s;e.alt='';e.draggable=false;return e}
function wireExisting(r){if(!r)return null;rigs.push(r);return r}
function build(host,kind){if(!host)return null;host.replaceChildren();host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);const r=document.createElement('div');r.className='mascotRig292';r.append(image('mascotPose292 mascotOpen292','icons/yay-puppet-open-v292.png?v=292'),image('mascotPose292 mascotBlink292','icons/yay-puppet-blink-v292.png?v=292'));host.append(r);rigs.push(r);return r}
function blink(r,doubleBlink=false){if(!r||reduced||document.hidden)return;const c=()=>{r.classList.add('isBlinking');setTimeout(()=>r.classList.remove('isBlinking'),155)};c();if(doubleBlink)setTimeout(c,270)}
function schedule(r){setTimeout(()=>{blink(r,Math.random()<.18);schedule(r)},2600+Math.random()*2200)}
const splash=wireExisting(document.querySelector('#scrobbleSplash .mascotRig292'))||build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');build(document.querySelector('#scrobble-v4 .yayButton'),'game');
rigs.forEach(schedule);
if(splash){setTimeout(()=>blink(splash,true),900);if(!reduced)setTimeout(()=>{splash.classList.add('doWelcome292');setTimeout(()=>splash.classList.remove('doWelcome292'),950)},1450)}
window.ScrobbleMascot={blink:()=>rigs.forEach(r=>blink(r,true)),wave:()=>{},celebrate:()=>{}};
}catch(e){console.warn('mascot 2.92',e)}})();