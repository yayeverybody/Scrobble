/* Scrobble 2.85 — integrated shoulder/sleeve arm pieces, fatter arms, slower dramatic ripple. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className; img.src=src; img.alt=alt; img.draggable=false;
      return img;
    }

    class ArmRenderer{
      constructor(canvas,src,side){
        this.canvas=canvas;
        this.ctx=canvas.getContext('2d');
        this.side=side;
        this.img=new Image();
        this.ready=false;
        this.raf=0;
        canvas.width=768; canvas.height=768;
        this.img.onload=()=>{this.ready=true;this.drawStatic();};
        this.img.src=src;
      }
      stop(){ if(this.raf) cancelAnimationFrame(this.raf); this.raf=0; this.drawStatic(); }
      drawStatic(){
        if(!this.ready)return;
        const c=this.ctx;c.clearRect(0,0,768,768);c.drawImage(this.img,0,0,768,768);
      }
      ripple(duration=2350,intensity=1){
        if(!this.ready||reduced)return;
        if(this.raf)cancelAnimationFrame(this.raf);
        const start=performance.now();
        const ctx=this.ctx,img=this.img,side=this.side;
        const rootX=side==='left'?665:103;
        const handX=side==='left'?145:623;
        const span=Math.abs(rootX-handX);
        // Perpendicular direction to the arm's diagonal axis.
        const px=side==='left'?-0.67:0.67;
        const py=0.74;
        const strip=5;
        const frame=(now)=>{
          const t=Math.min(1,(now-start)/duration);
          const fade=Math.sin(Math.PI*t); // starts/ends exactly at rest
          const phase=t*Math.PI*7.2;
          ctx.clearRect(0,0,768,768);
          // Draw vertical strips. The shoulder/sleeve has zero displacement; displacement grows toward the hand.
          for(let x=0;x<768;x+=strip){
            let along=side==='left'?(rootX-x)/span:(x-rootX)/span;
            along=Math.max(0,Math.min(1,along));
            const envelope=Math.pow(along,1.35);
            const traveling=Math.sin(phase - along*Math.PI*3.3);
            const secondary=Math.sin(phase*1.35 - along*Math.PI*5.4)*0.40;
            const amount=(traveling+secondary)*48*intensity*envelope*fade;
            const dx=px*amount,dy=py*amount;
            ctx.drawImage(img,x,0,strip+2,768,x+dx,dy,strip+2,768);
          }
          if(t<1)this.raf=requestAnimationFrame(frame);
          else{this.raf=0;this.drawStatic();}
        };
        this.raf=requestAnimationFrame(frame);
      }
    }

    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');
      host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');
      rig.className='mascotRig mascotRig284';
      rig.dataset.mascotKind=kind;
      const portal=document.createElement('div'); portal.className='mascotPortal';

      const leftJoint=document.createElement('div'); leftJoint.className='mascotArmJoint284 mascotArmJoint284--left';
      const rightJoint=document.createElement('div'); rightJoint.className='mascotArmJoint284 mascotArmJoint284--right';
      const leftCanvas=document.createElement('canvas'); leftCanvas.className='mascotArmCanvas284';
      const rightCanvas=document.createElement('canvas'); rightCanvas.className='mascotArmCanvas284';
      leftJoint.appendChild(leftCanvas); rightJoint.appendChild(rightCanvas);
      const leftRenderer=new ArmRenderer(leftCanvas,'icons/yay-puppet-arm-sleeve-v285.png','left');
      const rightRenderer=new ArmRenderer(rightCanvas,'icons/yay-puppet-arm-sleeve-right-v285.png','right');
      rig._armRenderers=[leftRenderer,rightRenderer];

      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-nosleeves-v284.png');
      const blinkImg=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-nosleeves-v284.png');
      rig.append(portal,leftJoint,rightJoint,body,blinkImg);
      host.appendChild(rig);
      rigs.push(rig);
      return rig;
    }

    function cancelJointAnimations(rig){
      rig.querySelectorAll('.mascotArmJoint284').forEach(el=>{try{el.getAnimations().forEach(a=>a.cancel())}catch(_){}});
    }

    // A normal wave is a true shoulder pivot: sleeve and arm rotate together as one piece.
    function shoulderWave(rig){
      if(!rig||reduced)return;
      cancelJointAnimations(rig);
      const l=rig.querySelector('.mascotArmJoint284--left');
      const r=rig.querySelector('.mascotArmJoint284--right');
      if(!l||!r)return;
      const o={duration:900,iterations:1,easing:'ease-in-out'};
      l.animate([{transform:'rotate(0deg)'},{transform:'rotate(-24deg)'},{transform:'rotate(12deg)'},{transform:'rotate(-8deg)'},{transform:'rotate(0deg)'}],o);
      r.animate([{transform:'rotate(0deg)'},{transform:'rotate(24deg)'},{transform:'rotate(-12deg)'},{transform:'rotate(8deg)'},{transform:'rotate(0deg)'}],o);
    }

    // Excited motion is deliberately NOT a broad wave. Shoulder stays nearly fixed while a traveling bend ripples to the hands.
    function excitedRipple(rig){
      if(!rig||reduced)return;
      cancelJointAnimations(rig);
      const l=rig.querySelector('.mascotArmJoint284--left');
      const r=rig.querySelector('.mascotArmJoint284--right');
      if(!l||!r)return;
      const o={duration:2350,iterations:1,easing:'ease-in-out'};
      l.animate([{transform:'rotate(0deg)'},{transform:'rotate(-7deg)'},{transform:'rotate(5deg)'},{transform:'rotate(-6deg)'},{transform:'rotate(0deg)'}],o);
      r.animate([{transform:'rotate(0deg)'},{transform:'rotate(7deg)'},{transform:'rotate(-5deg)'},{transform:'rotate(6deg)'},{transform:'rotate(0deg)'}],o);
      rig._armRenderers?.forEach(a=>a.ripple(2350,1));
    }

    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{rig.classList.add('isBlinking');setTimeout(()=>rig.classList.remove('isBlinking'),125);};
      close(); if(doubleBlink)setTimeout(close,260);
    }
    function scheduleBlink(rig){setTimeout(()=>{blink(rig,Math.random()<.14);scheduleBlink(rig)},7000+Math.random()*4000);}

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash){
      setTimeout(()=>blink(splash,true),900);
      // Show the new bend/ripple clearly on startup; tapping the mascot repeats it.
      setTimeout(()=>excitedRipple(splash),1450);
      splash.parentElement?.addEventListener('pointerdown',()=>excitedRipple(splash));
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>shoulderWave(rig)));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      Number(event.detail.points||0)>=25?excitedRipple(game):shoulderWave(game);
    });
    window.addEventListener('scrobble:game-over',()=>excitedRipple(game));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(r=>blink(r,true)),
      wave:()=>rigs.forEach(shoulderWave),
      celebrate:()=>rigs.forEach(excitedRipple)
    };
  }catch(e){console.warn('Mascot animation unavailable',e)}
})();
