-- Scrobble 2.39 — Player Profile Photos
-- Copy/paste this entire script into Supabase SQL Editor and run it once.

-- Public avatar images; uploads/removals are restricted to each signed-in user's own folder.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'avatars',
  'avatars',
  true,
  2097152,
  array['image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Scrobble avatars public read" on storage.objects;
create policy "Scrobble avatars public read"
on storage.objects for select
using (bucket_id = 'avatars');

drop policy if exists "Scrobble users upload own avatar" on storage.objects;
create policy "Scrobble users upload own avatar"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Scrobble users update own avatar" on storage.objects;
create policy "Scrobble users update own avatar"
on storage.objects for update
to authenticated
using (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Scrobble users delete own avatar" on storage.objects;
create policy "Scrobble users delete own avatar"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'avatars'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- profiles.avatar_url already exists in the current Scrobble schema.
-- Make sure authenticated players can read public profile identity fields through
-- the existing profile/RPC policies used by the game.
