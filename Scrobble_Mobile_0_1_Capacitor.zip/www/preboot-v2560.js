'use strict';
(function(){
  try{history.scrollRestoration='manual'}catch(e){}
  function top(){
    try{
      document.documentElement.scrollTop=0;
      if(document.body)document.body.scrollTop=0;
      window.scrollTo(0,0);
    }catch(e){}
  }
  top();
  window.addEventListener('pageshow',function(){
    top();
    requestAnimationFrame(function(){
      top();
      requestAnimationFrame(top);
    });
    setTimeout(top,300);
  },true);
  window.addEventListener('pagehide',top,true);
})();
