/* Scrobble 2.79 — stable two-arm mascot rig: fixed torso, socket-anchored arms, natural blink, excited flail. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className; img.src=src; img.alt=alt; img.draggable=false;
      return img;
    }
    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');
      host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');
      rig.className='mascotRig mascotRig279';
      rig.dataset.mascotKind=kind;
      const portal=document.createElement('div'); portal.className='mascotPortal';
      const left=layer('mascotArm279 mascotArm279--left','icons/yay-puppet-arm-v275.png');
      const right=layer('mascotArm279 mascotArm279--right','icons/yay-puppet-arm-right-v279.png');
      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-v275.png');
      const blinkImg=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-v275.png');
      rig.append(portal,left,right,body,blinkImg);
      host.appendChild(rig);
      rigs.push(rig);
      return rig;
    }
    function pulse(rig,name,duration){
      if(!rig||reduced)return;
      rig.classList.remove(name); void rig.offsetWidth; rig.classList.add(name);
      setTimeout(()=>rig.classList.remove(name),duration);
    }
    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{
        rig.classList.add('isBlinking');
        setTimeout(()=>rig.classList.remove('isBlinking'),125);
      };
      close();
      if(doubleBlink)setTimeout(close,260);
    }
    function scheduleBlink(rig){
      const next=7000+Math.random()*4000;
      setTimeout(()=>{
        blink(rig,Math.random()<.14);
        scheduleBlink(rig);
      },next);
    }

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash&&!reduced){
      setTimeout(()=>blink(splash,true),1500);
      setTimeout(()=>pulse(splash,'isExcited279',1500),2400);
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>pulse(rig,'isWave279',900)));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      const pts=Number(event.detail.points||0);
      pulse(game,pts>=25?'isExcited279':'isWave279',pts>=25?1500:900);
    });
    window.addEventListener('scrobble:game-over',()=>pulse(game,'isExcited279',1800));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(r=>blink(r,true)),
      wave:()=>rigs.forEach(r=>pulse(r,'isWave279',900)),
      celebrate:()=>rigs.forEach(r=>pulse(r,'isExcited279',1500))
    };
  }catch(_){/* mascot must never interfere with gameplay */}
})();
