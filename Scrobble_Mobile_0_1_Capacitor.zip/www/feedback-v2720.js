/* Scrobble 2.72 — isolated puppet-chaos sound and best-effort haptics. */
(()=>{
  'use strict';

  try{
    const AudioCtor=window.AudioContext||window.webkitAudioContext;
    let audio=null,master=null,noiseBuffer=null,unlocked=false;
    const timers=new Set();

    function later(fn,delay){
      const id=setTimeout(()=>{timers.delete(id);try{fn()}catch(_){}},delay);
      timers.add(id);
      return id
    }
    function unlock(){
      if(!AudioCtor)return null;
      try{
        if(!audio){
          audio=new AudioCtor();
          master=audio.createGain();
          master.gain.value=.22;
          master.connect(audio.destination)
        }
        if(audio.state==='suspended')audio.resume().catch(()=>{});
        unlocked=true;
        return audio
      }catch(_){return null}
    }
    ['pointerdown','touchstart','keydown'].forEach(type=>document.addEventListener(type,unlock,{capture:true,passive:true}));

    function ctx(){return unlocked?unlock():null}
    function vibrate(pattern){try{navigator.vibrate?.(pattern)}catch(_){}}
    function tone({from=440,to=440,duration=.1,delay=0,type='sine',volume=.12,attack=.006}={}){
      const c=ctx();if(!c||!master)return;
      const start=c.currentTime+delay,o=c.createOscillator(),g=c.createGain();
      o.type=type;o.frequency.setValueAtTime(Math.max(30,from),start);
      o.frequency.exponentialRampToValueAtTime(Math.max(30,to),start+duration);
      g.gain.setValueAtTime(.0001,start);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002,volume),start+attack);
      g.gain.exponentialRampToValueAtTime(.0001,start+duration);
      o.connect(g);g.connect(master);o.start(start);o.stop(start+duration+.02)
    }
    function noise(duration=.07,volume=.08,delay=0,highpass=180){
      const c=ctx();if(!c||!master)return;
      if(!noiseBuffer){
        noiseBuffer=c.createBuffer(1,Math.ceil(c.sampleRate*.5),c.sampleRate);
        const data=noiseBuffer.getChannelData(0);
        for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1
      }
      const start=c.currentTime+delay,s=c.createBufferSource(),filter=c.createBiquadFilter(),g=c.createGain();
      s.buffer=noiseBuffer;filter.type='highpass';filter.frequency.value=highpass;
      g.gain.setValueAtTime(volume,start);g.gain.exponentialRampToValueAtTime(.0001,start+duration);
      s.connect(filter);filter.connect(g);g.connect(master);s.start(start);s.stop(start+duration+.02)
    }

    function clack(){
      const wobble=(Math.random()-.5)*45;
      noise(.045,.1,0,520);tone({from:245+wobble,to:115,duration:.065,type:'triangle',volume:.13});
      if(Math.random()<.22)tone({from:720,to:540,duration:.055,delay:.025,type:'sine',volume:.045});
      vibrate(8)
    }
    function boop(){tone({from:310,to:155,duration:.11,type:'sine',volume:.1});vibrate(6)}
    function waveTap(){tone({from:165+Math.random()*55,to:105,duration:.045,type:'triangle',volume:.055})}
    function buttonPop(){tone({from:410,to:290,duration:.035,type:'sine',volume:.035})}
    function sadPass(){
      tone({from:255,to:190,duration:.18,type:'sawtooth',volume:.055});
      tone({from:190,to:118,duration:.25,delay:.15,type:'sawtooth',volume:.065});
      vibrate(14)
    }
    function bucketRattle(){
      [0,.045,.09,.135,.18,.225].forEach((d,i)=>{
        noise(.035,.065,d,350+i*90);
        tone({from:170+i*24,to:95+i*12,duration:.04,delay:d,type:'square',volume:.035})
      });
      vibrate([8,18,8,18,10])
    }
    function slideWhistle(){
      tone({from:760,to:185,duration:.43,type:'sine',volume:.095,attack:.018});
      tone({from:790,to:205,duration:.41,delay:.018,type:'triangle',volume:.03,attack:.018});
      vibrate([10,35,10])
    }
    function wordFanfare(points=0){
      const notes=points>=30?[392,523,659,784]:[392,494,659];
      notes.forEach((f,i)=>{
        tone({from:f*.96,to:f,duration:.13,delay:i*.085,type:'square',volume:.052});
        tone({from:f*2,to:f*2.02,duration:.1,delay:i*.085,type:'triangle',volume:.025})
      });
      const ticks=Math.min(8,Math.max(2,Math.ceil(Number(points||0)/8)));
      for(let i=0;i<ticks;i++)tone({from:150+i*28,to:105+i*20,duration:.035,delay:.29+i*.045,type:'triangle',volume:.045});
      tone({from:660,to:990,duration:.17,delay:.31+ticks*.045,type:'sine',volume:.075});
      vibrate(points>=30?[12,24,12,24,25]:[10,28,14])
    }
    function puppetBand(){
      bucketRattle();
      [262,330,392,523].forEach((f,i)=>tone({from:f*.86,to:f,duration:.18,delay:.25+i*.085,type:i%2?'square':'triangle',volume:.06}));
      tone({from:340,to:1040,duration:.48,delay:.34,type:'sine',volume:.075});
      later(()=>{noise(.12,.085,0,700);vibrate([18,35,18,35,35])},650)
    }

    const board=document.getElementById('board');
    let pendingKeys=null,pendingScheduled=false;
    function readPending(){
      const next=new Set();
      board?.querySelectorAll('.boardTile.pending').forEach(tile=>{
        const cell=tile.closest('.cell');
        if(cell)next.add(`${cell.dataset.r}-${cell.dataset.c}`)
      });
      if(pendingKeys!==null){
        const added=[...next].some(key=>!pendingKeys.has(key));
        const removed=[...pendingKeys].some(key=>{
          if(next.has(key))return false;
          const [r,c]=key.split('-');
          return !board.querySelector(`.cell[data-r="${r}"][data-c="${c}"] .boardTile`)
        });
        if(added)clack();else if(removed)boop()
      }
      pendingKeys=next
    }
    if(board){
      readPending();
      new MutationObserver(()=>{
        if(pendingScheduled)return;
        pendingScheduled=true;
        queueMicrotask(()=>{pendingScheduled=false;readPending()})
      }).observe(board,{childList:true,subtree:true})
    }

    window.addEventListener('scrobble:turn-ended',event=>{
      const detail=event.detail||{};
      if(detail.move_type==='play')wordFanfare(detail.points);
      else if(detail.move_type==='swap')bucketRattle();
      else if(detail.move_type==='pass')sadPass()
    });

    document.addEventListener('animationstart',event=>{
      if(event.target?.classList?.contains('lastMoveWave'))waveTap()
    },true);

    const wordOverlay=document.getElementById('wordOverlay');
    let wordOverlayWasOpen=false;
    if(wordOverlay)new MutationObserver(()=>{
      const open=!wordOverlay.classList.contains('hidden');
      if(open&&!wordOverlayWasOpen&&wordOverlay.querySelector('.recommendation.reject'))slideWhistle();
      wordOverlayWasOpen=open
    }).observe(wordOverlay,{attributes:true,attributeFilter:['class'],subtree:false});

    const gameOver=document.getElementById('gameOverOverlay');
    let gameOverWasOpen=false;
    if(gameOver)new MutationObserver(()=>{
      const open=!gameOver.classList.contains('hidden');
      if(open&&!gameOverWasOpen)puppetBand();
      gameOverWasOpen=open
    }).observe(gameOver,{attributes:true,attributeFilter:['class']});

    document.addEventListener('click',event=>{
      const button=event.target.closest?.('button');
      if(!button)return;
      if(button.id==='shuffle'){bucketRattle();return}
      if(['play','pass','swap'].includes(button.id))return;
      buttonPop()
    },true)
  }catch(_){/* Sound must never interfere with gameplay. */}
})();
