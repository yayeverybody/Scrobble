-- Scrobble 2.50 — Make It Weird
-- Run once in Supabase SQL Editor before deploying 2.50.

alter table public.games
  add column if not exists weird_rules jsonb not null default '[]'::jsonb;

create or replace function public.set_scrobble_weird_rules(p_game_id uuid, p_rules jsonb)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare uid uuid:=auth.uid();
begin
  if uid is null then raise exception 'Not signed in'; end if;
  if not exists(
    select 1 from public.game_players
    where game_id=p_game_id and player_id=uid and player_number=1
  ) then raise exception 'Only the game creator can set weird rules'; end if;

  update public.games
  set weird_rules=coalesce(p_rules,'[]'::jsonb), updated_at=now()
  where id=p_game_id;
end;
$$;
grant execute on function public.set_scrobble_weird_rules(uuid,jsonb) to authenticated;

create or replace function public.get_scrobble_invite_weirdness(p_invite_code text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare g public.games%rowtype; creator_name text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  select * into g from public.games where upper(invite_code)=upper(p_invite_code) limit 1;
  if g.id is null then return jsonb_build_object('rules','[]'::jsonb,'creator_name',null); end if;

  select p.display_name into creator_name
  from public.game_players gp
  left join public.profiles p on p.id=gp.player_id
  where gp.game_id=g.id and gp.player_number=1
  limit 1;

  return jsonb_build_object(
    'rules',coalesce(g.weird_rules,'[]'::jsonb),
    'creator_name',creator_name
  );
end;
$$;
grant execute on function public.get_scrobble_invite_weirdness(text) to authenticated;

create or replace function public.get_scrobble_game(p_game_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  g public.games%rowtype;
  gp public.game_players%rowtype;
  opp uuid; p1 uuid; p2 uuid; slot smallint;
  prof1 jsonb; prof2 jsonb;
  lm public.game_moves%rowtype;
  lm_player_number smallint;
  last_move_summary jsonb;
begin
  if uid is null then raise exception 'Not signed in'; end if;
  select * into gp from public.game_players where game_id=p_game_id and player_id=uid;
  if gp.game_id is null then raise exception 'You are not in this game'; end if;

  select * into g from public.games where id=p_game_id;
  select player_id into p1 from public.game_players where game_id=p_game_id and player_number=1;
  select player_id into p2 from public.game_players where game_id=p_game_id and player_number=2;
  select player_id into opp from public.game_players where game_id=p_game_id and player_id<>uid limit 1;
  slot := case when g.current_player_id=p1 then 0 else 1 end;

  select jsonb_build_object('id',p1,'display_name',p.display_name,'avatar_url',p.avatar_url)
    into prof1 from public.profiles p where p.id=p1;
  if prof1 is null then prof1:=jsonb_build_object('id',p1,'display_name',null,'avatar_url',null); end if;

  if p2 is not null then
    select jsonb_build_object('id',p2,'display_name',p.display_name,'avatar_url',p.avatar_url)
      into prof2 from public.profiles p where p.id=p2;
    if prof2 is null then prof2:=jsonb_build_object('id',p2,'display_name',null,'avatar_url',null); end if;
  end if;

  select * into lm from public.game_moves where game_id=p_game_id order by created_at desc,id desc limit 1;
  if lm.id is not null then
    select player_number into lm_player_number from public.game_players where game_id=p_game_id and player_id=lm.player_id;
    last_move_summary:=jsonb_build_object(
      'playedBy',greatest(coalesce(lm_player_number,1)-1,0),
      'move_type',lm.move_type,'words',coalesce(lm.words,'[]'::jsonb),'points',coalesce(lm.points,0)
    );
  end if;

  return jsonb_build_object(
    'id',g.id,'board',g.board,'bag',g.bag,
    'scores',jsonb_build_array(g.score_1,g.score_2),
    'current_player_id',g.current_player_id,'current_slot',slot,'player_number',gp.player_number,
    'rack',gp.rack,'opponent_id',opp,'status',g.status,'invite_code',g.invite_code,
    'updated_at',g.updated_at,'challenge',g.challenge,
    'player1_profile',prof1,'player2_profile',prof2,
    'lastMoveSummary',last_move_summary,
    'weird_rules',coalesce(g.weird_rules,'[]'::jsonb)
  );
end;
$$;
grant execute on function public.get_scrobble_game(uuid) to authenticated;
