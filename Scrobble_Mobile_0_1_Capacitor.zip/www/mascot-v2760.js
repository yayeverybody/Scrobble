/* Scrobble 2.76 — shoulder-anchored Yay Everybody puppet rig with facial animation. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className;img.src=src;img.alt=alt;img.draggable=false;
      return img
    }
    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');rig.className='mascotRig';rig.dataset.mascotKind=kind;
      const portal=document.createElement('div');portal.className='mascotPortal';
      const left=layer('mascotArm mascotArm--left','icons/yay-puppet-arm-v275.png');
      const right=layer('mascotArm mascotArm--right','icons/yay-puppet-arm-v275.png');
      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-v275.png');
      const blink=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-v275.png');
      rig.append(portal,left,right,body,blink);host.appendChild(rig);rigs.push(rig);
      return rig
    }
    function pulse(rig,name,duration){
      if(!rig||reduced)return;
      rig.classList.remove(name);void rig.offsetWidth;rig.classList.add(name);
      setTimeout(()=>rig.classList.remove(name),duration)
    }
    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{
        rig.classList.add('isBlinking');
        setTimeout(()=>rig.classList.remove('isBlinking'),120);
      };
      close();
      if(doubleBlink)setTimeout(close,245);
    }
    function faceBop(rig){
      if(!rig||reduced||document.hidden)return;
      rig.classList.remove('isFaceBopping');void rig.offsetWidth;rig.classList.add('isFaceBopping');
      setTimeout(()=>rig.classList.remove('isFaceBopping'),720);
    }
    function scheduleBlink(rig){
      const next=2200+Math.random()*3300;
      setTimeout(()=>{
        blink(rig,Math.random()<.22);
        if(Math.random()<.35)setTimeout(()=>faceBop(rig),360);
        scheduleBlink(rig);
      },next)
    }

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash&&!reduced){
      splash.classList.add('mascotIntro');
      setTimeout(()=>splash.classList.remove('mascotIntro'),2350);
      setTimeout(()=>faceBop(splash),1750)
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>pulse(rig,'isWaving',950)));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      pulse(game,Number(event.detail.points||0)>=25?'isCelebrating':'isWaving',Number(event.detail.points||0)>=25?1250:950)
    });
    window.addEventListener('scrobble:game-over',()=>pulse(game,'isCelebrating',1600));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(rig=>blink(rig,true)),
      face:()=>rigs.forEach(faceBop),
      wave:()=>rigs.forEach(rig=>pulse(rig,'isWaving',950)),
      celebrate:()=>rigs.forEach(rig=>pulse(rig,'isCelebrating',1250))
    }
  }catch(_){/* Mascot animation must never interfere with the game. */}
})();
