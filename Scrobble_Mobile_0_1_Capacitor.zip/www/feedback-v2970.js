/* Scrobble 2.96 — iOS-safe pre-rendered WAV feedback; no WebAudio synthesis. */
(()=>{'use strict';try{
  const files={
    tada:'sounds/tada.wav?v=297',clack:'sounds/clack.wav?v=297',boop:'sounds/boop.wav?v=297',tile:'sounds/tile.wav?v=297',slide:'sounds/slide-whistle-up.wav?v=297',
    button:'sounds/button.wav?v=297',pass:'sounds/pass.wav?v=297',swap:'sounds/swap.wav?v=297',
    reject:'sounds/reject.wav?v=297',fanfare:'sounds/fanfare.wav?v=297',gameover:'sounds/gameover.wav?v=297'
  };
  const audio={};
  for(const [k,src] of Object.entries(files)){
    const a=new Audio(src);a.preload='auto';a.playsInline=true;a.volume=k==='button'?.35:.55;audio[k]=a;
  }
  let unlocked=false,tadaPlayed=false;
  function play(name,vol){
    const a=audio[name];if(!a)return;
    try{
      a.pause();a.currentTime=0;
      if(typeof vol==='number')a.volume=vol;
      const p=a.play();if(p?.catch)p.catch(()=>{});
    }catch(_){}
  }
  function firstGesture(){
    if(unlocked)return;unlocked=true;
    // Play the welcome sound directly inside the user gesture on iOS.
    if(!tadaPlayed){tadaPlayed=true;play('tada',.62)}
  }
  ['pointerdown','touchstart','keydown'].forEach(t=>document.addEventListener(t,firstGesture,{capture:true,passive:true,once:true}));

  let draggingTile=false,sx=0,sy=0;
  document.addEventListener('pointerdown',e=>{const t=e.target.closest?.('.tile,.boardTile,.rackTile');if(!t)return;draggingTile=true;sx=e.clientX;sy=e.clientY},true);
  document.addEventListener('pointerup',e=>{if(!draggingTile)return;const moved=Math.hypot(e.clientX-sx,e.clientY-sy)>8;draggingTile=false;if(moved)setTimeout(()=>play('tile',.56),20)},true);
  document.addEventListener('pointercancel',()=>{draggingTile=false},true);
  const board=document.getElementById('board');
  let pendingKeys=null,pendingScheduled=false;
  function readPending(){
    const next=new Set();
    board?.querySelectorAll('.boardTile.pending').forEach(tile=>{
      const cell=tile.closest('.cell');if(cell)next.add(`${cell.dataset.r}-${cell.dataset.c}`)
    });
    if(pendingKeys!==null){
      const added=[...next].some(k=>!pendingKeys.has(k));
      const removed=[...pendingKeys].some(k=>{
        if(next.has(k))return false;
        const [r,c]=k.split('-');
        return !board.querySelector(`.cell[data-r="${r}"][data-c="${c}"] .boardTile`)
      });
      if(added)play('clack',.48);else if(removed)play('boop',.45)
    }
    pendingKeys=next
  }
  if(board){
    readPending();
    new MutationObserver(()=>{
      if(pendingScheduled)return;pendingScheduled=true;
      queueMicrotask(()=>{pendingScheduled=false;readPending()})
    }).observe(board,{childList:true,subtree:true})
  }

  window.addEventListener('scrobble:turn-ended',e=>{
    const d=e.detail||{};
    if(d.move_type==='play')play('slide',.62);
    else if(d.move_type==='swap')play('swap',.48);
    else if(d.move_type==='pass')play('pass',.50);
  });

  const wordOverlay=document.getElementById('wordOverlay');let wo=false;
  if(wordOverlay)new MutationObserver(()=>{
    const open=!wordOverlay.classList.contains('hidden');
    if(open&&!wo&&wordOverlay.querySelector('.recommendation.reject'))play('reject',.50);
    wo=open
  }).observe(wordOverlay,{attributes:true,attributeFilter:['class']});

  const gameOver=document.getElementById('gameOverOverlay');let go=false;
  if(gameOver)new MutationObserver(()=>{
    const open=!gameOver.classList.contains('hidden');
    if(open&&!go)play('gameover',.58);go=open
  }).observe(gameOver,{attributes:true,attributeFilter:['class']});

  document.addEventListener('click',e=>{
    const b=e.target.closest?.('button');if(!b)return;
    if(['play','pass','swap','shuffle'].includes(b.id))return;
    play('button',.32)
  },true);

  window.addEventListener('scrobble:mascot-tada',()=>{ if(unlocked&&!tadaPlayed){tadaPlayed=true;play('tada',.62)} });
}catch(_){}})();
