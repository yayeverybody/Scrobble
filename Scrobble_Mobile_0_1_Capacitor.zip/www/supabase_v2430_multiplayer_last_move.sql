-- Scrobble 2.43 — expose the latest multiplayer move so the opponent sees the played-word animation.
-- Run this once in Supabase SQL Editor before testing multiplayer animation.

create or replace function public.get_scrobble_game(p_game_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  g public.games%rowtype;
  gp public.game_players%rowtype;
  opp uuid;
  p1 uuid;
  p2 uuid;
  slot smallint;
  prof1 jsonb;
  prof2 jsonb;
  lm public.game_moves%rowtype;
  lm_player_number smallint;
  last_move_summary jsonb;
begin
  if uid is null then raise exception 'Not signed in'; end if;

  select * into gp
  from public.game_players
  where game_id=p_game_id and player_id=uid;

  if gp.game_id is null then raise exception 'You are not in this game'; end if;

  select * into g from public.games where id=p_game_id;
  select player_id into p1 from public.game_players where game_id=p_game_id and player_number=1;
  select player_id into p2 from public.game_players where game_id=p_game_id and player_number=2;
  select player_id into opp from public.game_players where game_id=p_game_id and player_id<>uid limit 1;

  slot := case when g.current_player_id=p1 then 0 else 1 end;

  -- Current Scrobble profile schema uses profiles.id = auth.users.id.
  select jsonb_build_object(
    'id',p1,
    'display_name',p.display_name,
    'avatar_url',p.avatar_url
  ) into prof1
  from public.profiles p
  where p.id=p1;

  if prof1 is null then
    prof1:=jsonb_build_object('id',p1,'display_name',null,'avatar_url',null);
  end if;

  if p2 is not null then
    select jsonb_build_object(
      'id',p2,
      'display_name',p.display_name,
      'avatar_url',p.avatar_url
    ) into prof2
    from public.profiles p
    where p.id=p2;

    if prof2 is null then
      prof2:=jsonb_build_object('id',p2,'display_name',null,'avatar_url',null);
    end if;
  end if;

  select * into lm
  from public.game_moves
  where game_id=p_game_id
  order by created_at desc, id desc
  limit 1;

  if lm.id is not null then
    select player_number into lm_player_number
    from public.game_players
    where game_id=p_game_id and player_id=lm.player_id;

    last_move_summary:=jsonb_build_object(
      'playedBy', greatest(coalesce(lm_player_number,1)-1,0),
      'move_type', lm.move_type,
      'words', coalesce(lm.words,'[]'::jsonb),
      'points', coalesce(lm.points,0)
    );
  else
    last_move_summary:=null;
  end if;

  return jsonb_build_object(
    'id',g.id,
    'board',g.board,
    'bag',g.bag,
    'scores',jsonb_build_array(g.score_1,g.score_2),
    'current_player_id',g.current_player_id,
    'current_slot',slot,
    'player_number',gp.player_number,
    'rack',gp.rack,
    'opponent_id',opp,
    'status',g.status,
    'invite_code',g.invite_code,
    'updated_at',g.updated_at,
    'challenge',g.challenge,
    'player1_profile',prof1,
    'player2_profile',prof2,
    'lastMoveSummary',last_move_summary
  );
end;
$$;

grant execute on function public.get_scrobble_game(uuid) to authenticated;
