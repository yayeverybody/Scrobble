(()=>{'use strict';
const el=document.getElementById('lastPlayBar');
if(!el)return;
function show(d){
  if(!d||d.move_type!=='play')return;
  const lm=d.last_move||{};
  const name=lm.playerName||((Number(d.playedBy)===0?document.getElementById('name1'):document.getElementById('name2'))?.textContent)||'Player';
  const words=(d.words||lm.words||[]).filter(Boolean);
  if(!words.length)return;
  const word=words.join(' / ');
  const pts=Number(d.points??lm.points??0);
  el.textContent=`${name} played ${word} for ${pts} point${pts===1?'':'s'}`;
}
window.addEventListener('scrobble:turn-ended',e=>show(e.detail||{}));
})();