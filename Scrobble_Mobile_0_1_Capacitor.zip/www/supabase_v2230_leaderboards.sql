-- Scrobble 2.23 — platform leaderboards
-- Run once in Supabase SQL Editor.
-- Creates a read-only RPC for authenticated Scrobble players.
-- "All-Time Wins" counts completed multiplayer games won.
-- "All-Time Points" sums each player's final score across completed multiplayer games.

create or replace function public.get_scrobble_leaderboards(p_limit integer default 25)
returns jsonb
language sql
security definer
set search_path = public
stable
as $$
with player_results as (
  select
    gp.player_id,
    gp.player_number,
    g.id as game_id,
    case when gp.player_number = 1 then coalesce(g.score_1,0)
         else coalesce(g.score_2,0) end as points,
    case
      when gp.player_number = 1 and coalesce(g.score_1,0) > coalesce(g.score_2,0) then 1
      when gp.player_number = 2 and coalesce(g.score_2,0) > coalesce(g.score_1,0) then 1
      else 0
    end as win
  from public.games g
  join public.game_players gp on gp.game_id = g.id
  where g.status = 'completed'
),
totals as (
  select
    pr.player_id,
    coalesce(p.display_name,'Player') as display_name,
    sum(pr.win)::bigint as wins,
    sum(pr.points)::bigint as points,
    count(*)::bigint as games_played
  from player_results pr
  left join public.profiles p on p.id = pr.player_id
  group by pr.player_id,p.display_name
),
wins_board as (
  select jsonb_agg(to_jsonb(x)) as rows
  from (
    select player_id,display_name,wins,points,games_played
    from totals
    order by wins desc, points desc, display_name asc
    limit greatest(1,least(coalesce(p_limit,25),100))
  ) x
),
points_board as (
  select jsonb_agg(to_jsonb(x)) as rows
  from (
    select player_id,display_name,wins,points,games_played
    from totals
    order by points desc, wins desc, display_name asc
    limit greatest(1,least(coalesce(p_limit,25),100))
  ) x
)
select jsonb_build_object(
  'wins', coalesce((select rows from wins_board),'[]'::jsonb),
  'points', coalesce((select rows from points_board),'[]'::jsonb)
);
$$;

grant execute on function public.get_scrobble_leaderboards(integer) to authenticated;
