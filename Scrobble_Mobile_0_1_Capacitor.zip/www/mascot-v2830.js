/* Scrobble 2.83 — direct Web Animations API arm motion. Keeps 2.82 geometry/shorter arms. */
(()=>{
  'use strict';
  try{
    const rigs=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

    function layer(className,src,alt=''){
      const img=document.createElement('img');
      img.className=className; img.src=src; img.alt=alt; img.draggable=false;
      return img;
    }
    function build(host,kind){
      if(!host)return null;
      host.textContent='';
      host.classList.add('mascotRigHost',`mascotRigHost--${kind}`);
      host.setAttribute('role','img');
      host.setAttribute('aria-label','Yay Everybody mascot');
      const rig=document.createElement('div');
      rig.className='mascotRig mascotRig279 mascotRig283';
      rig.dataset.mascotKind=kind;
      const portal=document.createElement('div'); portal.className='mascotPortal';

      const leftJoint=document.createElement('div');
      leftJoint.className='mascotArmJoint283 mascotArmJoint283--left';
      const rightJoint=document.createElement('div');
      rightJoint.className='mascotArmJoint283 mascotArmJoint283--right';

      const left=layer('mascotArm283','icons/yay-puppet-arm-v275.png');
      const right=layer('mascotArm283','icons/yay-puppet-arm-right-v279.png');
      leftJoint.appendChild(left); rightJoint.appendChild(right);

      const body=layer('mascotBody mascotBody--open','icons/yay-puppet-body-v275.png');
      const blinkImg=layer('mascotBody mascotBody--blink','icons/yay-puppet-blink-v275.png');
      rig.append(portal,leftJoint,rightJoint,body,blinkImg);
      host.appendChild(rig);
      rigs.push(rig);
      return rig;
    }

    function cancelArmAnimations(rig){
      rig.querySelectorAll('.mascotArmJoint283,.mascotArm283').forEach(el=>{
        try{el.getAnimations().forEach(a=>a.cancel())}catch(_){}
      });
    }

    function animateArms(rig,mode='wave'){
      if(!rig)return;
      const lj=rig.querySelector('.mascotArmJoint283--left');
      const rj=rig.querySelector('.mascotArmJoint283--right');
      const la=lj?.querySelector('.mascotArm283');
      const ra=rj?.querySelector('.mascotArm283');
      if(!lj||!rj||!la||!ra)return;
      cancelArmAnimations(rig);

      if(mode==='excited'){
        const jointOpts={duration:1650,iterations:1,easing:'ease-in-out'};
        lj.animate([
          {transform:'rotate(0deg)'},{transform:'rotate(-36deg)'},{transform:'rotate(25deg)'},
          {transform:'rotate(-31deg)'},{transform:'rotate(27deg)'},{transform:'rotate(-24deg)'},
          {transform:'rotate(19deg)'},{transform:'rotate(-12deg)'},{transform:'rotate(0deg)'}
        ],jointOpts);
        rj.animate([
          {transform:'rotate(0deg)'},{transform:'rotate(36deg)'},{transform:'rotate(-25deg)'},
          {transform:'rotate(31deg)'},{transform:'rotate(-27deg)'},{transform:'rotate(24deg)'},
          {transform:'rotate(-19deg)'},{transform:'rotate(12deg)'},{transform:'rotate(0deg)'}
        ],jointOpts);
        /* Inner counter-motion gives the arm a loose, rippling/floppy feel rather than one rigid stick. */
        const innerOpts={duration:825,iterations:2,easing:'ease-in-out'};
        la.animate([
          {transform:'rotate(0deg) skewY(0deg) scaleY(1)'},
          {transform:'rotate(10deg) skewY(5deg) scaleY(.96)'},
          {transform:'rotate(-8deg) skewY(-4deg) scaleY(1.04)'},
          {transform:'rotate(6deg) skewY(3deg) scaleY(.98)'},
          {transform:'rotate(0deg) skewY(0deg) scaleY(1)'}
        ],innerOpts);
        ra.animate([
          {transform:'rotate(0deg) skewY(0deg) scaleY(1)'},
          {transform:'rotate(-10deg) skewY(-5deg) scaleY(.96)'},
          {transform:'rotate(8deg) skewY(4deg) scaleY(1.04)'},
          {transform:'rotate(-6deg) skewY(-3deg) scaleY(.98)'},
          {transform:'rotate(0deg) skewY(0deg) scaleY(1)'}
        ],innerOpts);
      }else{
        const opts={duration:1100,iterations:1,easing:'ease-in-out'};
        lj.animate([{transform:'rotate(0deg)'},{transform:'rotate(-32deg)'},{transform:'rotate(18deg)'},{transform:'rotate(-13deg)'},{transform:'rotate(0deg)'}],opts);
        rj.animate([{transform:'rotate(0deg)'},{transform:'rotate(32deg)'},{transform:'rotate(-18deg)'},{transform:'rotate(13deg)'},{transform:'rotate(0deg)'}],opts);
      }
    }

    function blink(rig,doubleBlink=false){
      if(!rig||reduced||document.hidden)return;
      const close=()=>{
        rig.classList.add('isBlinking');
        setTimeout(()=>rig.classList.remove('isBlinking'),125);
      };
      close(); if(doubleBlink)setTimeout(close,260);
    }
    function scheduleBlink(rig){
      setTimeout(()=>{blink(rig,Math.random()<.14);scheduleBlink(rig)},7000+Math.random()*4000);
    }

    const splash=build(document.querySelector('#scrobbleSplash .splashMascot'),'splash');
    const dashboard=build(document.querySelector('#scrobble-dashboard .dashMascot'),'dashboard');
    const game=build(document.querySelector('#scrobble-v4 .yayButton'),'game');
    rigs.forEach(scheduleBlink);

    if(splash){
      setTimeout(()=>blink(splash,true),900);
      /* Two unmistakable demos before the 4.15s splash closes. */
      setTimeout(()=>animateArms(splash,'wave'),1250);
      setTimeout(()=>animateArms(splash,'excited'),2450);
      splash.parentElement?.addEventListener('pointerdown',()=>animateArms(splash,'excited'));
    }
    [dashboard,game].forEach(rig=>rig?.parentElement?.addEventListener('click',()=>animateArms(rig,'wave')));

    window.addEventListener('scrobble:turn-ended',event=>{
      if(event.detail?.move_type!=='play')return;
      animateArms(game,Number(event.detail.points||0)>=25?'excited':'wave');
    });
    window.addEventListener('scrobble:game-over',()=>animateArms(game,'excited'));

    window.ScrobbleMascot={
      blink:()=>rigs.forEach(r=>blink(r,true)),
      wave:()=>rigs.forEach(r=>animateArms(r,'wave')),
      celebrate:()=>rigs.forEach(r=>animateArms(r,'excited'))
    };
  }catch(e){console.warn('Mascot animation unavailable',e)}
})();
