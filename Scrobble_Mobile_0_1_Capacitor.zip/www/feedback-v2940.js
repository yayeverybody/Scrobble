/* Scrobble 2.74 — louder, stranger puppet-chaos feedback. */
(()=>{
  'use strict';

  try{
    const AudioCtor=window.AudioContext||window.webkitAudioContext;
    let audio=null,master=null,noiseBuffer=null,unlocked=false,splashPending=false,splashPlayed=true,tadaPending=true,tadaPlayed=false;
    const timers=new Set();

    function later(fn,delay){
      const id=setTimeout(()=>{timers.delete(id);try{fn()}catch(_){}},delay);
      timers.add(id);
      return id
    }
    function finishUnlock(){
      unlocked=true;
      if(audio?.state==='running'){
        // Prime the output on iOS with a near-silent one-sample source while still in the gesture chain.
        try{
          const b=audio.createBuffer(1,1,audio.sampleRate),s=audio.createBufferSource(),g=audio.createGain();
          g.gain.value=.00001;s.buffer=b;s.connect(g);g.connect(master);s.start(0)
        }catch(_){}
        playPendingSplash();
        playPendingTada();
      }
      return audio
    }
    function unlock(){
      if(!AudioCtor)return null;
      try{
        if(!audio){
          audio=new AudioCtor();
          master=audio.createGain();
          master.gain.value=.34;
          master.connect(audio.destination)
        }
        unlocked=true;
        if(audio.state==='suspended'){
          const resumed=audio.resume();
          if(resumed&&typeof resumed.then==='function')resumed.then(finishUnlock).catch(()=>{});
        }else finishUnlock();
        return audio
      }catch(_){return null}
    }
    function unlockFromGesture(){
      unlock();
      // Some iOS builds report running only after the current gesture callback returns.
      setTimeout(()=>{try{finishUnlock()}catch(_){}},0)
    }
    ['pointerdown','touchstart','keydown'].forEach(type=>document.addEventListener(type,unlockFromGesture,{capture:true,passive:true}));

    function ctx(){return unlocked?unlock():null}
    function vibrate(pattern){try{navigator.vibrate?.(pattern)}catch(_){}}
    function tone({from=440,to=440,duration=.1,delay=0,type='sine',volume=.12,attack=.006}={}){
      const c=ctx();if(!c||!master)return;
      const start=c.currentTime+delay,o=c.createOscillator(),g=c.createGain();
      o.type=type;o.frequency.setValueAtTime(Math.max(30,from),start);
      o.frequency.exponentialRampToValueAtTime(Math.max(30,to),start+duration);
      g.gain.setValueAtTime(.0001,start);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002,volume),start+attack);
      g.gain.exponentialRampToValueAtTime(.0001,start+duration);
      o.connect(g);g.connect(master);o.start(start);o.stop(start+duration+.02)
    }
    function noise(duration=.07,volume=.08,delay=0,highpass=180){
      const c=ctx();if(!c||!master)return;
      if(!noiseBuffer){
        noiseBuffer=c.createBuffer(1,Math.ceil(c.sampleRate*.5),c.sampleRate);
        const data=noiseBuffer.getChannelData(0);
        for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1
      }
      const start=c.currentTime+delay,s=c.createBufferSource(),filter=c.createBiquadFilter(),g=c.createGain();
      s.buffer=noiseBuffer;filter.type='highpass';filter.frequency.value=highpass;
      g.gain.setValueAtTime(volume,start);g.gain.exponentialRampToValueAtTime(.0001,start+duration);
      s.connect(filter);filter.connect(g);g.connect(master);s.start(start);s.stop(start+duration+.02)
    }

    function bend(points,{duration=.25,delay=0,type='sine',volume=.1}={}){
      const c=ctx();if(!c||!master)return;
      const start=c.currentTime+delay,o=c.createOscillator(),g=c.createGain();
      o.type=type;o.frequency.setValueAtTime(points[0],start);
      points.slice(1).forEach((f,i)=>o.frequency.exponentialRampToValueAtTime(Math.max(30,f),start+duration*(i+1)/(points.length-1)));
      g.gain.setValueAtTime(.0001,start);g.gain.exponentialRampToValueAtTime(volume,start+.012);g.gain.exponentialRampToValueAtTime(.0001,start+duration);
      o.connect(g);g.connect(master);o.start(start);o.stop(start+duration+.03)
    }
    function puppetVowel(pitchPoints,formants,{duration=.3,delay=0,volume=.08}={}){
      const c=ctx();if(!c||!master)return;
      const start=c.currentTime+delay,o=c.createOscillator(),voice=c.createGain();
      o.type='sawtooth';o.frequency.setValueAtTime(pitchPoints[0],start);
      pitchPoints.slice(1).forEach((f,i)=>o.frequency.exponentialRampToValueAtTime(f,start+duration*(i+1)/(pitchPoints.length-1)));
      voice.gain.setValueAtTime(.0001,start);voice.gain.exponentialRampToValueAtTime(volume,start+.025);voice.gain.setValueAtTime(volume,start+duration*.7);voice.gain.exponentialRampToValueAtTime(.0001,start+duration);
      o.connect(voice);
      formants.forEach(([frequency,q,gain])=>{const filter=c.createBiquadFilter(),level=c.createGain();filter.type='bandpass';filter.frequency.value=frequency;filter.Q.value=q;level.gain.value=gain;voice.connect(filter);filter.connect(level);level.connect(master)});
      o.start(start);o.stop(start+duration+.03)
    }

    function wooHoo(){
      if(splashPlayed)return;splashPlayed=true;splashPending=false;
      puppetVowel([155,245,205],[[310,7,1.25],[820,9,.65]],{duration:.34,volume:.085});
      puppetVowel([225,390,315],[[360,7,1.2],[1050,10,.7]],{duration:.38,delay:.29,volume:.095});
      bend([520,920,610],{duration:.2,delay:.48,type:'triangle',volume:.055});
      noise(.07,.035,.61,900);vibrate([10,25,20])
    }
    function playPendingSplash(){if(splashPending&&audio?.state==='running')wooHoo()}
    function attemptSplash(){
      if(!AudioCtor||splashPlayed)return;
      unlock();
      if(audio?.state==='running')wooHoo()
    }

    function mascotTada(){
      if(tadaPlayed)return;
      const c=ctx(); if(!c||!master){tadaPending=true;return;}
      tadaPlayed=true;tadaPending=false;
      // Short orchestral-style crescendo into a bright "TA-DA!" cadence.
      [196,247,294].forEach((f,i)=>tone({from:f*.72,to:f,duration:.72,delay:i*.025,type:'sawtooth',volume:.026,attack:.34}));
      noise(.55,.018,.04,520);
      [392,494,587].forEach((f,i)=>tone({from:f*.96,to:f,duration:.20,delay:.66+i*.012,type:'triangle',volume:.075,attack:.012}));
      [523,659,784,1047].forEach((f,i)=>tone({from:f*.98,to:f,duration:.48,delay:.91+i*.012,type:'triangle',volume:.095,attack:.008}));
      noise(.08,.055,.91,1200);
      vibrate([10,35,16]);
    }

    function playPendingTada(){if(tadaPending&&audio?.state==='running')mascotTada();}

    function clack(){
      const wobble=(Math.random()-.5)*65;
      noise(.055,.13,0,420);bend([285+wobble,105,165],{duration:.09,type:'triangle',volume:.15});
      if(Math.random()<.5)bend([880,1120,510],{duration:.12,delay:.025,type:'sine',volume:.07});
      vibrate(8)
    }
    function boop(){bend([240,520,125],{duration:.19,type:'sine',volume:.14});noise(.035,.045,.02,850);vibrate(6)}
    function waveTap(){bend([210+Math.random()*90,480,135],{duration:.075,type:'triangle',volume:.075})}
    function buttonPop(){bend([370,610,260],{duration:.065,type:'sine',volume:.055})}
    function sadPass(){
      puppetVowel([180,145,112],[[520,6,1],[980,9,.45]],{duration:.34,volume:.08});
      bend([280,245,120,92],{duration:.48,delay:.12,type:'sawtooth',volume:.075});
      vibrate(14)
    }
    function bucketRattle(){
      [0,.045,.09,.135,.18,.225].forEach((d,i)=>{
        noise(.045,.095,d,280+i*80);
        bend([145+i*27,310-i*12,82+i*15],{duration:.06,delay:d,type:i%2?'square':'triangle',volume:.055})
      });
      vibrate([8,18,8,18,10])
    }
    function slideWhistle(){
      bend([920,1280,710,165],{duration:.52,type:'sine',volume:.13});
      bend([960,1340,760,185],{duration:.5,delay:.018,type:'triangle',volume:.045});
      vibrate([10,35,10])
    }
    function wordFanfare(points=0){
      const notes=points>=30?[330,523,784,1046]:[330,494,740];
      notes.forEach((f,i)=>{
        bend([f*.72,f*1.18,f],{duration:.15,delay:i*.09,type:'square',volume:.075});
        tone({from:f*2.03,to:f*1.94,duration:.12,delay:i*.09,type:'triangle',volume:.035})
      });
      const ticks=Math.min(8,Math.max(2,Math.ceil(Number(points||0)/8)));
      for(let i=0;i<ticks;i++)tone({from:150+i*28,to:105+i*20,duration:.035,delay:.29+i*.045,type:'triangle',volume:.045});
      bend([440,1180,760,1320],{duration:.31,delay:.31+ticks*.045,type:'sine',volume:.11});
      vibrate(points>=30?[12,24,12,24,25]:[10,28,14])
    }
    function puppetBand(){
      bucketRattle();
      [262,370,523,784].forEach((f,i)=>bend([f*.65,f*1.3,f],{duration:.2,delay:.25+i*.09,type:i%2?'square':'triangle',volume:.085}));
      puppetVowel([160,330,235,410],[[430,6,1],[1150,9,.55]],{duration:.58,delay:.36,volume:.075});
      later(()=>{noise(.12,.085,0,700);vibrate([18,35,18,35,35])},650)
    }

    const board=document.getElementById('board');
    let pendingKeys=null,pendingScheduled=false;
    function readPending(){
      const next=new Set();
      board?.querySelectorAll('.boardTile.pending').forEach(tile=>{
        const cell=tile.closest('.cell');
        if(cell)next.add(`${cell.dataset.r}-${cell.dataset.c}`)
      });
      if(pendingKeys!==null){
        const added=[...next].some(key=>!pendingKeys.has(key));
        const removed=[...pendingKeys].some(key=>{
          if(next.has(key))return false;
          const [r,c]=key.split('-');
          return !board.querySelector(`.cell[data-r="${r}"][data-c="${c}"] .boardTile`)
        });
        if(added)clack();else if(removed)boop()
      }
      pendingKeys=next
    }
    if(board){
      readPending();
      new MutationObserver(()=>{
        if(pendingScheduled)return;
        pendingScheduled=true;
        queueMicrotask(()=>{pendingScheduled=false;readPending()})
      }).observe(board,{childList:true,subtree:true})
    }

    window.addEventListener('scrobble:turn-ended',event=>{
      const detail=event.detail||{};
      if(detail.move_type==='play')wordFanfare(detail.points);
      else if(detail.move_type==='swap')bucketRattle();
      else if(detail.move_type==='pass')sadPass()
    });

    document.addEventListener('animationstart',event=>{
      if(event.target?.classList?.contains('lastMoveWave'))waveTap()
    },true);

    const wordOverlay=document.getElementById('wordOverlay');
    let wordOverlayWasOpen=false;
    if(wordOverlay)new MutationObserver(()=>{
      const open=!wordOverlay.classList.contains('hidden');
      if(open&&!wordOverlayWasOpen&&wordOverlay.querySelector('.recommendation.reject'))slideWhistle();
      wordOverlayWasOpen=open
    }).observe(wordOverlay,{attributes:true,attributeFilter:['class'],subtree:false});

    const gameOver=document.getElementById('gameOverOverlay');
    let gameOverWasOpen=false;
    if(gameOver)new MutationObserver(()=>{
      const open=!gameOver.classList.contains('hidden');
      if(open&&!gameOverWasOpen)puppetBand();
      gameOverWasOpen=open
    }).observe(gameOver,{attributes:true,attributeFilter:['class']});

    document.addEventListener('click',event=>{
      const button=event.target.closest?.('button');
      if(!button)return;
      if(button.id==='shuffle'){bucketRattle();return}
      if(['play','pass','swap'].includes(button.id))return;
      buttonPop()
    },true);

    window.addEventListener('scrobble:mascot-tada',mascotTada);

    later(()=>{tadaPending=true;mascotTada()},420)
  }catch(_){/* Sound must never interfere with gameplay. */}
})();
