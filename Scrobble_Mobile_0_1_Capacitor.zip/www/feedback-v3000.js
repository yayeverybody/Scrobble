/* Scrobble 3.00 — real recorded public-domain sound effects. No synthesized/TTS effects. */
(()=>{'use strict';try{
  const MASTER=.22;

  // Real field recordings from PDSounds, hosted by Wikimedia Commons (public domain).
  const SOURCES={
    tile:'https://upload.wikimedia.org/wikipedia/commons/d/d2/Hitting_wooden_pole.ogg',
    woo:'https://upload.wikimedia.org/wikipedia/commons/a/a8/Clapping_hurray.ogg'
  };

  const audio={};
  for(const [name,src] of Object.entries(SOURCES)){
    const a=new Audio(src);
    a.preload='auto';
    a.playsInline=true;
    a.volume=MASTER;
    audio[name]=a;
  }

  let unlocked=false;
  function unlock(){
    if(unlocked)return;
    unlocked=true;
    // No startup sound. Merely request buffering after the user's first gesture.
    for(const a of Object.values(audio)){ try{a.load()}catch(_){} }
  }
  ['pointerdown','touchstart','keydown'].forEach(t=>
    document.addEventListener(t,unlock,{capture:true,passive:true})
  );

  function playSegment(name,start,duration,volume=MASTER){
    if(!unlocked)return;
    const a=audio[name]; if(!a)return;
    try{
      a.pause();
      a.currentTime=start;
      a.volume=volume;
      const p=a.play();
      const stop=()=>setTimeout(()=>{
        try{a.pause();a.currentTime=start}catch(_){}
      },duration*1000);
      if(p&&typeof p.then==='function')p.then(stop).catch(()=>{});
      else stop();
    }catch(_){}
  }

  // Real wood clack whenever a tile is actually dragged and released.
  let drag=false,sx=0,sy=0;
  document.addEventListener('pointerdown',e=>{
    if(!e.target.closest?.('.tile,.boardTile,.rackTile'))return;
    drag=true;sx=e.clientX;sy=e.clientY;
  },true);
  document.addEventListener('pointerup',e=>{
    if(!drag)return;
    const moved=Math.hypot(e.clientX-sx,e.clientY-sy)>8;
    drag=false;
    if(moved)setTimeout(()=>playSegment('tile',0,.22,MASTER),20);
  },true);
  document.addEventListener('pointercancel',()=>{drag=false},true);

  // Real human "hurray / woohoo" recording after a successful played word.
  window.addEventListener('scrobble:turn-ended',e=>{
    const d=e.detail||{};
    if(d.move_type==='play')playSegment('woo',0,1.65,MASTER);
  });

  // Deliberately no synthesized button/pass/swap/reject/game-over/startup effects in 3.00.
}catch(e){console.warn('feedback 3.00',e)}})();
