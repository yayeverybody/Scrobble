/* Scrobble 3.01 — actual recorded sound effects only. */
(()=>{'use strict';try{
  const MASTER=.22;

  // Actual recorded source files. No synthesis or TTS.
  const SOURCES={
    // Public-domain recorded wood impact.
    tile:'https://upload.wikimedia.org/wikipedia/commons/d/d2/Hitting_wooden_pole.ogg?scrobble=301',
    // Human voice actor saying "Woohoo!" (OpenGameArt).
    woo:'https://opengameart.org/sites/default/files/woohoo.ogg?scrobble=301'
  };

  const audio={};
  for(const [name,src] of Object.entries(SOURCES)){
    const a=new Audio();
    a.preload='auto';
    a.playsInline=true;
    a.volume=MASTER;
    a.src=src;
    audio[name]=a;
  }

  let unlocked=false;
  function unlock(){
    if(unlocked)return;
    unlocked=true;
    for(const a of Object.values(audio)){try{a.load()}catch(_){}}
  }
  ['pointerdown','touchstart','keydown'].forEach(t=>
    document.addEventListener(t,unlock,{capture:true,passive:true})
  );

  function play(name,volume=MASTER){
    if(!unlocked)return;
    const a=audio[name]; if(!a)return;
    try{
      a.pause(); a.currentTime=0; a.volume=volume;
      const p=a.play(); p?.catch?.(()=>{});
    }catch(_){}
  }

  // Wooden clack when a tile is dragged and dropped/moved.
  let drag=false,sx=0,sy=0;
  document.addEventListener('pointerdown',e=>{
    if(!e.target.closest?.('.tile,.boardTile,.rackTile'))return;
    drag=true; sx=e.clientX; sy=e.clientY;
  },true);
  document.addEventListener('pointerup',e=>{
    if(!drag)return;
    const moved=Math.hypot(e.clientX-sx,e.clientY-sy)>8;
    drag=false;
    if(moved)setTimeout(()=>play('tile',MASTER),20);
  },true);
  document.addEventListener('pointercancel',()=>{drag=false},true);

  // Actual human woo-hoo when a word is successfully played.
  window.addEventListener('scrobble:turn-ended',e=>{
    const d=e.detail||{};
    if(d.move_type==='play')play('woo',MASTER);
  });

  // No startup ta-da. No slide whistle. No generated metallic effects.
}catch(e){console.warn('feedback 3.01',e)}})();
