/* Scrobble 2.99 — hard-reset sound layer with unique 2.99 assets. */
(()=>{'use strict';try{
  const MASTER=.25; // half of the earlier normal effect level
  const files={
    tile:'sounds299/tile-clack-299.wav',
    woo:'sounds299/woo-hoo-299.wav',
    button:'sounds299/button-299.wav',
    pass:'sounds299/pass-299.wav',
    swap:'sounds299/swap-299.wav',
    reject:'sounds299/reject-299.wav',
    gameover:'sounds299/gameover-299.wav',
    boop:'sounds299/boop-299.wav'
  };
  const pool={};
  for(const [k,src] of Object.entries(files)){
    const a=new Audio(src+'?build=299');a.preload='auto';a.playsInline=true;a.volume=MASTER;pool[k]=a;
  }
  let unlocked=false;
  function play(name,mult=1){
    const a=pool[name];if(!a||!unlocked)return;
    try{a.pause();a.currentTime=0;a.volume=Math.max(0,Math.min(1,MASTER*mult));const p=a.play();p?.catch?.(()=>{})}catch(_){}
  }
  // Unlock only. NO splash ta-da or startup sound.
  function unlock(){if(unlocked)return;unlocked=true;
    const a=pool.button;
    if(a){a.volume=0;const p=a.play();p?.then(()=>{a.pause();a.currentTime=0;a.volume=MASTER}).catch(()=>{})}
  }
  ['pointerdown','touchstart','keydown'].forEach(t=>document.addEventListener(t,unlock,{capture:true,passive:true}));

  // Sound every genuine tile drag release, whether rack -> board or board -> board.
  let drag=false,sx=0,sy=0;
  document.addEventListener('pointerdown',e=>{
    if(!e.target.closest?.('.tile,.boardTile,.rackTile'))return;
    drag=true;sx=e.clientX;sy=e.clientY;
  },true);
  document.addEventListener('pointerup',e=>{
    if(!drag)return;const moved=Math.hypot(e.clientX-sx,e.clientY-sy)>8;drag=false;
    if(moved)setTimeout(()=>play('tile',1),25);
  },true);
  document.addEventListener('pointercancel',()=>{drag=false},true);

  window.addEventListener('scrobble:turn-ended',e=>{
    const d=e.detail||{};
    if(d.move_type==='play')play('woo',1);
    else if(d.move_type==='swap')play('swap',.9);
    else if(d.move_type==='pass')play('pass',.9);
  });

  const wordOverlay=document.getElementById('wordOverlay');let wo=false;
  if(wordOverlay)new MutationObserver(()=>{
    const open=!wordOverlay.classList.contains('hidden');
    if(open&&!wo&&wordOverlay.querySelector('.recommendation.reject'))play('reject',.9);
    wo=open
  }).observe(wordOverlay,{attributes:true,attributeFilter:['class']});

  const gameOver=document.getElementById('gameOverOverlay');let go=false;
  if(gameOver)new MutationObserver(()=>{
    const open=!gameOver.classList.contains('hidden');
    if(open&&!go)play('gameover',1);go=open
  }).observe(gameOver,{attributes:true,attributeFilter:['class']});

  document.addEventListener('click',e=>{
    const b=e.target.closest?.('button');if(!b)return;
    if(['play','pass','swap','shuffle'].includes(b.id))return;
    play('button',.7)
  },true);
}catch(e){console.warn('feedback 2.99',e)}})();
