# Scrobble Mobile 0.1

This project is the **unchanged stable Scrobble 3.14 web game** placed inside a clean Capacitor 8 project.

The goal of this package is deliberately boring: get the existing game running as a native iPhone/Android app before changing visuals, gameplay, authentication, notifications, or branding.

## Project layout

- `www/` — the complete Scrobble 3.14 web app
- `capacitor.config.json` — native app identity and web directory
- `package.json` — Capacitor dependencies and commands
- `MOBILE_CHECKLIST.md` — what to test and what will probably need native adaptation
- `codemagic.yaml` — starter cloud-build workflow

App ID: `com.yayeverybody.scrobble`
App name: `Scrobble`

## Local setup

Requires Node 22+.

```bash
npm install
npx cap add ios
npx cap add android
npx cap sync
```

A Mac is required to compile iOS locally. Because the project owner does not have a Mac, the intended iOS path is a cloud macOS builder such as Codemagic.

Android can be built locally with Android Studio or through the same cloud builder.

## First milestone

Do not redesign anything yet.

The first milestone is:

1. Install dependencies.
2. Generate the iOS native project.
3. Compile in a cloud Mac environment.
4. Install through TestFlight.
5. Sign in.
6. Start or accept a real multiplayer game.
7. Play through a complete game.
8. Verify that returning to the app preserves the game correctly.

Only after that baseline works should native push notifications, deep links, sharing, haptics, app splash/icon, and other native integrations be added.

## Important: existing web behavior

This package intentionally preserves the Scrobble 3.14 HTML/CSS/JavaScript unchanged.

That means some browser-oriented features will probably need a native pass:

- Google OAuth / Supabase redirect handling
- Web Push notifications
- invitation/deep links
- service-worker/PWA behavior
- native share sheet
- safe areas around iPhone notches/Dynamic Island
- background/resume behavior

Those are expected second-stage tasks, not reasons to rewrite Scrobble.

## Cloud iOS build

`codemagic.yaml` is included as a starter. Apple signing/App Store Connect credentials must be connected in the cloud build service before a signed TestFlight build can be produced.

Do not commit Apple certificates, private keys, passwords, or App Store Connect API secrets to this repository.
