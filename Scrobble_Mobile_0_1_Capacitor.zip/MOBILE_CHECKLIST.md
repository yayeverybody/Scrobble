# Scrobble Mobile Test Checklist

## Baseline — must work before native enhancements

- [ ] App launches without a blank screen
- [ ] Splash dismisses normally
- [ ] Existing Scrobble account can sign in
- [ ] Games dashboard loads
- [ ] Existing active games appear
- [ ] New game can be created
- [ ] Invitation can be accepted
- [ ] Tiles drag and snap correctly
- [ ] Pinch zoom works
- [ ] One-finger pan works while zoomed
- [ ] Dictionary validation works
- [ ] Opponent accept/deny flow works
- [ ] Pass works
- [ ] Swap works
- [ ] Playing final tile ends the game correctly
- [ ] Rematch keeps the same opponent
- [ ] App can be backgrounded and reopened without losing state

## Expected native follow-up

- [ ] Configure Supabase/Google OAuth for native redirect URLs
- [ ] Replace browser Web Push with native push notifications
- [ ] Add universal/app links for game invitations
- [ ] Use native share sheet
- [ ] Add haptic feedback
- [ ] Verify iPhone safe-area spacing
- [ ] Add production app icon and native splash screen
- [ ] Test offline/poor-network behavior
- [ ] Test on Android
